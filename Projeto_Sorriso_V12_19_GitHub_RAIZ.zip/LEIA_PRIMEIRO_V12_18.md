# Projeto Sorriso V12.18 — pacote GitHub atualizado

Atenção: o ZIP `Projeto_Sorriso_V12_18_GitHub_RAIZ.zip` coloca `package.json`, `src/`, `public/` e `tests/` **direto na pasta raiz** de um projeto GitHub. Ele não cria outra pasta `Projeto_Sorriso_Online_V12`.

Para instalar no Codespaces: faça upload deste ZIP na raiz do repositório, realize Commit changes e no terminal execute:

```bash
cd "$(git rev-parse --show-toplevel)"
git pull --ff-only
unzip -oq Projeto_Sorriso_V12_18_GitHub_RAIZ.zip
npm run check
npm test
npm run deploy
```

Se o código do seu aplicativo estiver numa subpasta do repositório, descompacte o ZIP **dentro dessa subpasta** (que já contém `package.json`).

Versão testada: 12.18.0. Contém perseguidor sem dano por jumpscare, cutscene de apelidos, e pontos de interação individuais. Testes automatizados: 62/62 no ambiente de desenvolvimento. A publicação real precisa de suas credenciais Cloudflare e deve ser feita depois dos testes.
