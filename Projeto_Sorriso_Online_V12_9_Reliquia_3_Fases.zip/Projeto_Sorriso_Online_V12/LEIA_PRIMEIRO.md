# Projeto Sorriso Online V12.9

## Como publicar

Leia `LEIA_PRIMEIRO_V12_9.md` para os comandos. A versão 12.9 mantém a Cloudflare e a pasta interna `Projeto_Sorriso_Online_V12`.

Esta versão reforça a luta da Relíquia de Energia em três fases; preserva multiplayer, curas, cartas, mapa cósmico e a integração da OST da V12.8.
