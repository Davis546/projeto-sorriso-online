import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,statSync} from 'node:fs';

const client=readFileSync(new URL('../public/client.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../public/index.html',import.meta.url),'utf8');

test('OST enviada inicia na introducao e segue na luta da Reliquia',()=>{
 assert.match(client,/const RELIQUIA_OST='reliquia-invasion'/);
 assert.match(client,/w\.phase==='boss_intro'\|\|b\?\.kind==='energia'\)playMusic\(RELIQUIA_OST\)/);
 assert.match(client,/b\.kind==='energia'\?RELIQUIA_OST/);
 assert.match(client,/audio\.loop=true/);
 const mp3=new URL('../public/audio/reliquia-invasion.mp3',import.meta.url);
 assert.ok(statSync(mp3).size>1000000);
 assert.match(html,/V12\.9 RELÍQUIA 3 FASES/);
});
