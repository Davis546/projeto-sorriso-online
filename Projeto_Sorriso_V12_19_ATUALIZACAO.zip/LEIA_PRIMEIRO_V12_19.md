# Projeto Sorriso V12.19 — Cinemática dos cinco agentes em tela cheia

Atualização da campanha: ao interagir com a estação VHS, **a cutscene aparece na tela** em todos os computadores e celulares conectados à sala. O jogador vê os cinco sprites adolescentes (Solar, Ritual, Alvo, Feras e Lunar), aquele que está falando recebe destaque animado, o nome e o diálogo aparecem em legendas grandes, e existe progresso visual da sequência. O apresentador invade a imagem no final. Só após a última fala a perseguição de 2008 começa.

O ZIP contém os arquivos do projeto **na raiz**: `package.json`, `public`, `src` e `tests`.

No GitHub Codespaces, a partir da pasta com o `package.json`:

```bash
unzip -oq Projeto_Sorriso_V12_19_GitHub_RAIZ.zip
npm run check
npm test
npm run deploy
```

Para atualizar o código remoto, faça commit dos arquivos alterados. A publicação Cloudflare requer autenticação configurada na sua conta.
