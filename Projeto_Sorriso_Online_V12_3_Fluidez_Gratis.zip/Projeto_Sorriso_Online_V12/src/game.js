// Projeto Sorriso Online V12 — regras AUTORITATIVAS no servidor.
// Não usa módulos externos, pode ser testado com Node.
export const IDS = ['solar','ritual','alvo','feras','lunar'];
export const STATS = {
 solar:{hp:190,speed:225,damage:84,rate:.85,skill:9},
 ritual:{hp:175,speed:218,damage:34,rate:.52,skill:10},
 alvo:{hp:240,speed:245,damage:72,rate:.49,skill:10},
 feras:{hp:250,speed:230,damage:15,rate:.63,skill:10},
 lunar:{hp:185,speed:228,damage:34,rate:.61,skill:12}
};
const B={l:155,r:1380,t:310,b:900}, rnd=(a,b)=>a+Math.random()*(b-a), clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
const d2=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const activeP=w=>Object.values(w.players).filter(p=>p.connected&&p.agent&&p.hp>0);
export function makeRoom(code){return {code,host:null,phase:'lobby',wave:0,players:{}, enemies:[],shots:[],warnings:[],effects:[],toSpawn:0,spawnCd:0,between:0,bossKind:null,ult:0,cardDeadline:0,seq:0,lastTime:Date.now(),message:'Esperando agentes',bossSeen:false};}
export function joinRoom(w,token,name){
 const old=w.players[token]; if(old){old.connected=true;return old;}
 if(w.phase!=='lobby')throw Error('PARTIDA_INICIADA');
 if(Object.keys(w.players).length>=5)throw Error('SALA_CHEIA');
 const p={token,name:String(name||'Agente').trim().slice(0,18)||'Agente',agent:null,ready:false,connected:true,
 x:700,y:620,hp:0,maxHp:0,shield:0,cd:0,skillCd:0,dashCd:0,inv:0,dir:0,fx:0,damage:0,speed:0,rate:1,skill:10,upgrades:[],choices:[],chosen:false,attackBonus:0,moveBonus:0,healBonus:0,projectiles:0,crit:0,range:0,bleed:0,attackHolding:false,inp:{x:0,y:0,fire:false,aim:0,ts:0}};
 w.players[token]=p;if(!w.host)w.host=token;return p;
}
export function chooseAgent(w,token,agent){const p=w.players[token];if(!p||w.phase!=='lobby'||!IDS.includes(agent))return false;
 if(Object.values(w.players).some(o=>o!==p&&o.agent===agent))return false;
 p.agent=agent;p.ready=false;return true;
}
export function readyUp(w,token){const p=w.players[token];if(p&&w.phase==='lobby'&&p.agent)p.ready=!p.ready;}
export function disconnect(w,token){const p=w.players[token];if(!p)return;p.connected=false;p.inp={x:0,y:0,fire:false,aim:0,ts:0};
 if(w.phase==='lobby'){delete w.players[token];if(w.host===token)w.host=Object.keys(w.players)[0]||null;}else if(w.host===token){w.host=Object.values(w.players).find(q=>q.connected)?.token||token;}
}
export function launch(w,token){if(w.host!==token||w.phase!=='lobby')return false;const ps=Object.values(w.players);if(!ps.length||ps.some(p=>!p.agent||!p.connected||!p.ready))return false;
 ps.forEach((p,i)=>{const s=STATS[p.agent];Object.assign(p,{x:560+i*90,y:560+(i%2)*65,hp:s.hp,maxHp:s.hp,damage:s.damage,speed:s.speed,rate:s.rate,skill:s.skill,cd:0,skillCd:0,dashCd:0,inv:0,shield:0,fx:0,attackBonus:0,moveBonus:0,healBonus:0,projectiles:0,crit:0,range:0,bleed:0,upgrades:[],chosen:false,choices:[]});});
 w.ult=0;w.wave=0;startWave(w);return true;
}
function startWave(w){w.wave++;w.phase='fight';w.bossKind=w.wave%5===0?['sol','diretora','tv'][((w.wave/5)-1)%3]:null;w.bossSeen=false;
 w.toSpawn=w.bossKind?7+Math.floor(w.wave/4):8+Math.min(22,Math.floor(w.wave*2.1));w.spawnCd=.9;w.message=w.bossKind?'O CHEFE ESTÁ NA TRANSMISSÃO':'ONDA '+String(w.wave).padStart(2,'0');w.warnings=[];w.shots=[];
 if(w.bossKind)spawn(w,w.bossKind);
}
function spawn(w,kind){if(!kind){const r=Math.random();kind=r<.30?'sangue':r<.50?'rastejante':r<.70?'monitor':r<.84?'cacador':r<.94?'bruto':'devoto'}
 const boss=['sol','diretora','tv'].includes(kind),types={sangue:[110,95,17,20],rastejante:[80,150,13,18],monitor:[160,78,19,24],cacador:[205,156,24,21],bruto:[340,80,31,28],devoto:[230,75,20,24],sol:[5700,90,33,58],diretora:[6600,105,34,56],tv:[8000,130,43,58]};
 const [hp,speed,dmg,r]=types[kind],m=boss?1+Math.floor(w.wave/15)*.22:1+Math.max(0,w.wave-1)*.10;
 const edge=Math.floor(rnd(0,4));const x=edge===0?B.l:edge===1?B.r:rnd(B.l+50,B.r-50), y=edge===2?B.t:edge===3?B.b:rnd(B.t+50,B.b-50);
 w.enemies.push({id:++w.seq,kind,x:boss?830:x,y:boss?485:y,hp:Math.round(hp*m),maxHp:Math.round(hp*m),speed:speed*(boss?1:Math.min(1.5,1+w.wave*.012)),dmg:dmg+Math.floor(w.wave/5)*2,r,cd:rnd(0,1),shoot:rnd(.4,2),patternCd:boss?2.2:3,teleportCd:2,phase2:false,bleed:0,bleedTick:.5,stun:0,armor:0,move:0});
}
function near(w,p,max=900){let target=null,best=max;for(const e of w.enemies){const d=d2(p,e);if(e.hp>0&&d<best){best=d;target=e}}return target;}
function addEffect(w,fx){w.effects.push({...fx,createdAt:Date.now()});if(w.effects.length>60)w.effects.splice(0,w.effects.length-60);}
function dmgEnemy(w,e,amount,p){if(!e||e.hp<=0)return;
 const boss=['sol','diretora','tv'].includes(e.kind);let d=amount*(e.armor>0?.66:1);
 if(boss)d=Math.min(d,210)*(e.phase2?.82:1);const before=e.hp;e.hp=Math.max(0,e.hp-d);
 if(p){w.ult=clamp(w.ult+Math.min(2,(before-e.hp)*.012),0,100)}
 if(e.hp===0){w.ult=clamp(w.ult+(boss?16:2),0,100);addEffect(w,{t:'kill',x:e.x,y:e.y,id:++w.seq});}
}
function hurt(p,d){if(p.hp<=0||p.inv>0)return;let amt=Math.max(0,d-(p.shield>0?0:0));if(p.shield>0){const s=Math.min(p.shield,amt);p.shield-=s;amt-=s;}p.hp=Math.max(0,p.hp-amt);p.inv=.35;}
function addShot(w,x,y,dx,dy,team,dmg,color,speed=550,life=1.5,r=8,owner=null,range=0){const m=Math.hypot(dx,dy)||1;w.shots.push({id:++w.seq,x,y,vx:dx/m*speed,vy:dy/m*speed,team,dmg,color,life,r,owner,range});}
function fire(w,p){const e=near(w,p,p.agent==='solar'?1020:630);if(!e)return;
 const a=Math.atan2(e.y-p.y,e.x-p.x);p.dir=a;p.cd=p.rate*(p.fx>0?.65:1);const bonus=1+p.attackBonus;
 if(p.agent==='alvo'){
  for(const q of w.enemies){if(q.hp<=0)continue;const d=d2(p,q),an=Math.atan2(q.y-p.y,q.x-p.x);if(d<112+p.range+q.r&&Math.cos(an-a)>.45){dmgEnemy(w,q,(p.damage*bonus)*(Math.random()<p.crit?1.75:1),p);q.bleed=Math.max(q.bleed,2+p.bleed);q.stun=.12;}}
  addEffect(w,{t:'axe',x:p.x,y:p.y,a,id:++w.seq});
 }else if(p.agent==='feras'){
  for(let i=0;i<7+p.projectiles;i++){const ang=a+(i-(6+p.projectiles)/2)*.11;addShot(w,p.x,p.y,Math.cos(ang),Math.sin(ang),'good',p.damage*bonus,'#ff7986',770,.43,5,p.token)}
 }else if(p.agent==='ritual'||p.agent==='lunar'){
  for(let i=0;i<1+p.projectiles;i++){const aa=a+(i-(p.projectiles)/2)*.12;addShot(w,p.x,p.y,Math.cos(aa),Math.sin(aa),'good',p.damage*bonus,p.agent==='ritual'?'#cf99ff':'#ffc3e9',580,1.4,9,p.token)}
 }else{for(let i=0;i<1+p.projectiles;i++){const aa=a+(i-p.projectiles/2)*.10;addShot(w,p.x,p.y,Math.cos(aa),Math.sin(aa),'good',p.damage*bonus,'#ffe2a1',1400,1.1,6,p.token)}}
 addEffect(w,{t:'muzzle',x:p.x,y:p.y,a,id:++w.seq});
}
function skill(w,p){if(p.skillCd>0||p.hp<=0)return;p.skillCd=p.skill;const e=near(w,p,850);p.fx=.35;
 if(p.agent==='solar'&&e){for(const q of w.enemies)if(q.hp>0&&d2(e,q)<175)dmgEnemy(w,q,210*(1+p.attackBonus),p);addEffect(w,{t:'laser',x:p.x,y:p.y,x2:e.x,y2:e.y,id:++w.seq});}
 if(p.agent==='ritual'&&e){for(const q of w.enemies)if(d2(e,q)<220){dmgEnemy(w,q,120*(1+p.attackBonus),p);q.stun=.65;}addEffect(w,{t:'ritual',x:e.x,y:e.y,id:++w.seq});}
 if(p.agent==='alvo'){for(const q of w.enemies)if(d2(p,q)<205){dmgEnemy(w,q,155*(1+p.attackBonus),p);q.bleed=4+p.bleed;}p.hp=Math.min(p.maxHp,p.hp+23+p.healBonus);addEffect(w,{t:'blood',x:p.x,y:p.y,id:++w.seq});}
 if(p.agent==='feras'){p.fx=5.4;p.shield=Math.min(100,p.shield+35);addEffect(w,{t:'rage',x:p.x,y:p.y,id:++w.seq});}
 if(p.agent==='lunar'){for(const q of Object.values(w.players))if(q.hp>0){q.hp=Math.min(q.maxHp,q.hp+q.maxHp*(.24+p.healBonus/300));q.shield=Math.min(105,q.shield+24);}addEffect(w,{t:'heal',x:p.x,y:p.y,id:++w.seq});}
}
function bossAttack(w,e){const ps=activeP(w);if(!ps.length)return;const p=ps[Math.floor(Math.random()*ps.length)];const phase=e.phase2,kind=e.kind;
 if(kind==='tv'){
  const a=rnd(0,Math.PI*2);e.x=clamp(p.x+Math.cos(a)*160,B.l+90,B.r-90);e.y=clamp(p.y+Math.sin(a)*160,B.t+85,B.b-85);
  addEffect(w,{t:'warp',x:e.x,y:e.y,id:++w.seq});
  warn(w,{type:'circle',x:p.x,y:p.y,r:phase?130:103,dmg:phase?65:48,duration:.75,color:'#ff6b88'});
  if(phase)warn(w,{type:'circle',x:clamp(p.x+70,B.l+85,B.r-85),y:p.y,r:78,dmg:38,duration:1.0,color:'#ff6b88'});
 }else if(kind==='sol'){
  const a=Math.atan2(p.y-e.y,p.x-e.x);for(let i=-1;i<=1;i++)warn(w,{type:'beam',x:e.x,y:e.y,a:a+i*(phase?.32:.45),len:900,r:phase?38:29,dmg:phase?50:37,duration:.92,color:'#ffbd75'});
 }else{
  for(let i=0;i<(phase?6:4);i++){const q=ps[i%ps.length];warn(w,{type:'circle',x:clamp(q.x+rnd(-110,110),B.l+65,B.r-65),y:clamp(q.y+rnd(-100,100),B.t+60,B.b-60),r:phase?95:70,dmg:phase?44:32,duration:.83,color:'#bb8afc'});}
 }
 if(Math.random()<.28&&w.enemies.length<15)spawn(w,'cacador');
}
function warn(w,v){w.warnings.push({...v,id:++w.seq,life:v.duration});}
function segmentDistance(p,x,y,x2,y2){let vx=x2-x,vy=y2-y;const t=clamp(((p.x-x)*vx+(p.y-y)*vy)/(vx*vx+vy*vy||1),0,1);return Math.hypot(p.x-x-t*vx,p.y-y-t*vy);}
function resolveWarn(w,z){for(const p of activeP(w)){const hit=z.type==='circle'?Math.hypot(p.x-z.x,p.y-z.y)<z.r+15:segmentDistance(p,z.x,z.y,z.x+Math.cos(z.a)*z.len,z.y+Math.sin(z.a)*z.len)<z.r+15;if(hit)hurt(p,z.dmg);}addEffect(w,{t:'impact',x:z.x,y:z.y,id:++w.seq});}
const CARD_POOL={
 base:[['vigor','🛡️','Vitalidade','+40 de PV máximo','common'],['passos','👟','Passos Sombrios','+14% de velocidade','common'],['forca','⚔️','Precisão Mortal','+17% de dano','common'],['protege','🔰','Armadura Improvisada','+28 de escudo','rare'],['critico','💥','Golpe Crítico','+10% de chance crítica','rare'],['cura','💚','Primeiros Socorros','Cura 30 PV imediatamente','common']],
 solar:[['sniper','🎯','Projétil Solar','+30% de dano com sniper','rare'],['duplo','🔫','Tiro Gêmeo','+1 disparo por ataque','epic'],['critico','☀️','Olho do Sol','+10% de crítico','rare']],
 ritual:[['orbe','🔮','Runa Dupla','+1 orbe paranormal','epic'],['forca','📜','Conhecimento Profundo','+17% de dano ritual','rare'],['vigor','🌀','Mente Resistente','+40 de vida','common']],
 alvo:[['machado','🪓','Fúria Carmesim','+32% dano do machado','rare'],['alcance','🩸','Lâmina Ampliada','+25 alcance corpo a corpo','epic'],['sangue','🩸','Sangramento Ritual','+3s de sangramento','rare']],
 feras:[['chumbo','💣','Chumbo Duplo','+2 fragmentos da doze','epic'],['forca','🐺','Instinto da Matilha','+17% dano','common'],['passos','🔥','Corrida Selvagem','+14% velocidade','rare']],
 lunar:[['orbe','🌙','Ecos Lunares','+1 projétil paranormal','epic'],['heal','💗','Luz de Cura','+25 PV de cura ao usar especial','rare'],['proteger','🦋','Proteção Lunar','+28 de escudo','common']]
};
function rollChoices(p){const pool=[...CARD_POOL.base,...CARD_POOL[p.agent]];const out=[],used=new Set();while(out.length<3){const c=pool[Math.floor(Math.random()*pool.length)];if(!used.has(c[1]+c[2])){used.add(c[1]+c[2]);out.push(c)}}return out;}
function applyCard(p,card){const t=card[0];if(t==='vigor'){p.maxHp+=40;p.hp+=40;}else if(t==='passos')p.moveBonus=Math.min(.9,p.moveBonus+.14);else if(['forca','sniper','machado'].includes(t))p.attackBonus+=t==='forca'?.17:t==='sniper'?.30:.32;
 else if(t==='protege'||t==='proteger')p.shield=Math.min(150,p.shield+28);else if(t==='critico')p.crit=Math.min(.65,p.crit+.10);else if(t==='cura')p.hp=Math.min(p.maxHp,p.hp+30);else if(t==='duplo'||t==='orbe')p.projectiles=Math.min(4,p.projectiles+1);else if(t==='alcance')p.range+=25;else if(t==='sangue')p.bleed+=3;else if(t==='chumbo')p.projectiles=Math.min(7,p.projectiles+2);else if(t==='heal')p.healBonus+=25;
 p.upgrades.push({title:card[2],rarity:card[4]});}
export function pickCard(w,token,index){const p=w.players[token];if(!p||w.phase!=='cards'||p.chosen)return false;if(!Number.isInteger(index)||index<0||index>=p.choices.length)return false;
 applyCard(p,p.choices[index]);p.chosen=true;p.choices=[];checkCards(w);return true;}
function checkCards(w){if(Object.values(w.players).filter(p=>p.agent&&p.connected).every(p=>p.chosen)){w.phase='between';w.between=2.0;w.message='TODOS EQUIPADOS';}}
function finishWave(w){w.phase='cards';w.cardDeadline=Date.now()+45000;w.message='ESCOLHA UMA CARTA';w.enemies=[];w.shots=[];w.warnings=[];
 for(const p of Object.values(w.players)){if(p.agent){if(p.hp<=0)p.hp=p.maxHp*.36;else p.hp=Math.min(p.maxHp,p.hp+p.maxHp*.13);p.choices=rollChoices(p);p.chosen=!p.connected;}}
 checkCards(w);
}
export function setInput(w,token,v){const p=w.players[token];if(!p||w.phase!=='fight'||!p.connected)return;const x=Number(v.x)||0,y=Number(v.y)||0;p.inp={x:clamp(x,-1,1),y:clamp(y,-1,1),fire:!!v.fire,aim:clamp(Number(v.aim)||0,-Math.PI*4,Math.PI*4),ts:Date.now()};
 if(v.skill)skill(w,p);
 if(v.dash&&p.dashCd<=0&&p.hp>0){const d=Math.hypot(x,y)||1;p.x=clamp(p.x+(x/d)*155,B.l+22,B.r-22);p.y=clamp(p.y+(y/d)*155,B.t+22,B.b-22);p.dashCd=4.1;p.inv=.46;addEffect(w,{t:'dash',x:p.x,y:p.y,id:++w.seq});}
 if(v.ult&&w.ult>=100&&activeP(w).length){w.ult=0;w.message='TRANSMISSÃO ZERO!';addEffect(w,{t:'ultimate',x:760,y:540,id:++w.seq});for(const e of w.enemies)if(e.hp>0)dmgEnemy(w,e,['sol','diretora','tv'].includes(e.kind)?870:1400,p);for(const ally of activeP(w)){ally.hp=Math.min(ally.maxHp,ally.hp+35);ally.shield=Math.min(100,ally.shield+18);}}
}
export function advance(w,now=Date.now()){
 const dt=clamp((now-w.lastTime)/1000,0,.10);w.lastTime=now;
 if(w.phase==='lobby'||w.phase==='over')return;
 if(w.phase==='cards'){if(now>w.cardDeadline){for(const p of Object.values(w.players))if(p.agent&&!p.chosen){applyCard(p,p.choices[0]);p.chosen=true;p.choices=[];}checkCards(w);}return;}
 if(w.phase==='between'){w.between-=dt;if(w.between<=0)startWave(w);return;}
 if(w.phase!=='fight')return;
 w.effects=w.effects.filter(fx=>now-fx.createdAt<420);
 const ps=activeP(w);
 if(ps.length===0){w.phase='over';w.message='TRANSMISSÃO INTERROMPIDA';return;}
 for(const p of Object.values(w.players)){
  if(p.hp<=0||!p.agent)continue;p.cd=Math.max(0,p.cd-dt);p.skillCd=Math.max(0,p.skillCd-dt);p.dashCd=Math.max(0,p.dashCd-dt);p.inv=Math.max(0,p.inv-dt);p.fx=Math.max(0,p.fx-dt);
  if(!p.connected||now-p.inp.ts>500)continue;const dx=p.inp.x,dy=p.inp.y,len=Math.hypot(dx,dy);if(len>.12){const mult=p.speed*(1+p.moveBonus);p.x=clamp(p.x+dx/Math.max(1,len)*mult*dt,B.l+22,B.r-22);p.y=clamp(p.y+dy/Math.max(1,len)*mult*dt,B.t+22,B.b-22);p.dir=Math.atan2(dy,dx);}
  if(p.inp.fire&&p.cd<=0)fire(w,p);
 }
 w.spawnCd-=dt;if(w.toSpawn>0&&w.spawnCd<=0&&w.enemies.filter(e=>e.hp>0).length<18){spawn(w);w.toSpawn--;w.spawnCd=Math.max(.28,.88-w.wave*.012);}
 for(const e of w.enemies){if(e.hp<=0)continue; e.cd-=dt;e.shoot-=dt;e.stun=Math.max(0,e.stun-dt);e.armor=Math.max(0,e.armor-dt);e.move+=dt;
 if(e.bleed>0){e.bleed=Math.max(0,e.bleed-dt);e.bleedTick-=dt;if(e.bleedTick<=0){e.bleedTick=.5;dmgEnemy(w,e,9,null);}}if(e.hp<=0)continue;
 let p=null,dist=1e9;for(const q of ps){const d=d2(e,q);if(d<dist){dist=d;p=q;}}if(!p)continue;
 const dx=p.x-e.x,dy=p.y-e.y,v=e.speed*(e.phase2?1.21:1),r=e.r+20,boss=['sol','diretora','tv'].includes(e.kind);
 if(!boss&&e.stun<=0){if(dist>r){e.x+=dx/dist*v*dt;e.y+=dy/dist*v*dt;}if(dist<r+8&&e.cd<=0){hurt(p,e.dmg);e.cd=e.kind==='cacador'?.75:1.0;}}
 if((e.kind==='monitor'||e.kind==='devoto')&&e.shoot<=0&&dist<700){e.shoot=e.kind==='monitor'?2:2.6;addShot(w,e.x,e.y,dx,dy,'bad',e.dmg,'#a1e9e4',320,2.0,6);}
 if(boss){if(!e.phase2&&e.hp<e.maxHp*.5){e.phase2=true;e.armor=3.2;w.message='ATO II • O SINAL DESPERTOU';for(let i=0;i<3;i++)spawn(w,i%2?'cacador':'devoto');}
  if(e.stun<=0){if(dist>185){e.x+=dx/dist*v*.63*dt;e.y+=dy/dist*v*.63*dt;}if(dist<r+16&&e.cd<=0){hurt(p,e.dmg);e.cd=.90;}}
  e.patternCd-=dt;if(e.patternCd<=0){bossAttack(w,e);e.patternCd=e.phase2?2.2:3.35;}
  if(e.shoot<=0){e.shoot=e.phase2?1.35:1.8;for(let i=-1;i<=1;i++){const a=Math.atan2(dy,dx)+i*.19;addShot(w,e.x,e.y,Math.cos(a),Math.sin(a),'bad',e.dmg*.55,'#ff8898',320,2.5,8);}}
 }
 e.x=clamp(e.x,B.l+30,B.r-30);e.y=clamp(e.y,B.t+30,B.b-30);
 }
 for(const s of w.shots){s.x+=s.vx*dt;s.y+=s.vy*dt;s.life-=dt;if(s.x<B.l||s.x>B.r||s.y<B.t||s.y>B.b){s.life=0;continue;}if(s.team==='good'){for(const e of w.enemies){if(e.hp>0&&Math.hypot(s.x-e.x,s.y-e.y)<s.r+e.r){dmgEnemy(w,e,s.dmg,w.players[s.owner]);s.life=0;break;}}}else{for(const p of ps)if(Math.hypot(s.x-p.x,s.y-p.y)<s.r+17){hurt(p,s.dmg);s.life=0;break;}}}
 w.shots=w.shots.filter(s=>s.life>0);
 for(const z of w.warnings){z.life-=dt;if(z.life<=0)resolveWarn(w,z);}w.warnings=w.warnings.filter(z=>z.life>0);
 w.enemies=w.enemies.filter(e=>e.hp>0);
 if(w.toSpawn<=0&&!w.enemies.length)finishWave(w);
}
export function snapshot(w,token){const p=w.players[token];return {type:'state',code:w.code,phase:w.phase,host:w.host===token,you:token,wave:w.wave,bossKind:w.bossKind,ult:Math.round(w.ult),message:w.message,
 players:Object.values(w.players).map(p=>({token:p.token,name:p.name,agent:p.agent,ready:p.ready,connected:p.connected,x:Math.round(p.x),y:Math.round(p.y),speed:p.speed*(1+p.moveBonus),hp:Math.ceil(p.hp),maxHp:p.maxHp,shield:Math.ceil(p.shield),cd:p.cd,skillCd:p.skillCd,dashCd:p.dashCd,upgrades:p.upgrades.length,chosen:p.chosen,fx:p.fx,dir:p.dir,move:p.inp.x||p.inp.y})),
 enemies:w.enemies.map(e=>({id:e.id,kind:e.kind,x:Math.round(e.x),y:Math.round(e.y),hp:Math.ceil(e.hp),maxHp:e.maxHp,r:e.r,phase2:e.phase2,move:e.move,armor:e.armor})),
 shots:w.shots.map(s=>({x:Math.round(s.x),y:Math.round(s.y),team:s.team,r:s.r,color:s.color})),warnings:w.warnings.map(z=>({...z,life:Math.max(0,z.life)})),effects:w.effects,
 choices:p?.choices||[],chosen:!!p?.chosen,cardDeadline:w.phase==='cards'?w.cardDeadline:0};}
