# 📺 Projeto Sorriso Online — V12 (2025)

Esta versão é um **protótipo jogável de arena cooperativa online** para até **5 jogadores reais**. Os jogadores entram na mesma sala privada com código, escolhem agentes diferentes e enfrentam ondas, chefes e cartas roguelike em equipe.

## O que já funciona

- Até cinco pessoas conectadas na mesma partida; um Solar, Ritual, Alvo, Feras e Lunar por sala.
- Sala privada por código de 8 caracteres, link de convite, confirmação de pronto e início pelo líder.
- Movimento, tiros, machado de sangue, rituais, habilidades, esquiva e vidas compartilhadas pela simulação do servidor.
- Monstros e três chefes: **Sol Sorridente** (onda 5), **Diretora** (onda 10) e **chefe da TV** (onda 15). A sequência se repete.
- **Transmissão Zero** quando a barra coletiva chega a 100%.
- Após cada onda, cada jogador escolhe sua própria carta roguelike.
- Retorno à sala após desconexão temporária usando o token daquele navegador, enquanto a sessão for recuperável.
- Sprites dos cinco agentes, monstros, arena e trilhas sonoras originais reaproveitadas da V11.
- Controles para PC (WASD/setas + espaço para atacar, E ritual, Shift esquiva, F supremo) e controles na tela para celular.

**Limitações da V12:** a história com Sandra, Yuri, os cinco puzzles e o Confessor **ainda é solo**; está incluída no arquivo `public/historia-v11.html` e acessível pelo menu. A arena multiplayer foi reimplementada como um protótipo de regras compartilhadas. O balanceamento não é idêntico ao combate offline da V11. Ainda não há contas, progressão permanente, voz integrada nem mapa exploratório online. Não foi realizado teste real com cinco aparelhos conectados à Cloudflare.

## Publicar na internet — passo a passo no computador

### 1. Criar uma conta

Entre em [dash.cloudflare.com](https://dash.cloudflare.com/) e crie uma conta gratuita (ou use a que já tem). Não precisa comprar domínio para usar o endereço `*.workers.dev` que a Cloudflare oferece.

### 2. Preparar o computador

Instale **Node.js LTS** em [nodejs.org](https://nodejs.org/). Descompacte `Projeto_Sorriso_Online_V12.zip`. Abra um terminal **dentro** da pasta `Projeto_Sorriso_Online_V12`, onde fica o arquivo `package.json`.

### 3. Instalar as dependências

```bash
npm install
```

### 4. Entrar na Cloudflare

```bash
npx wrangler login
```

Abra o navegador quando solicitado e autorize o login. Se for a primeira vez usando Workers, a Cloudflare poderá pedir que você configure o subdomínio gratuito `workers.dev` na sua conta.

### 5. Publicar o jogo e o servidor juntos

```bash
npm run deploy
```

O terminal deve mostrar o endereço público, parecido com `https://projeto-sorriso-online.SEUSUBDOMINIO.workers.dev`. Esse endereço é seu jogo; **não precisa contratar hospedagem separada**. A sala funciona enquanto o projeto estiver implantado na Cloudflare e dentro dos limites do seu plano.

### 6. Jogar com os amigos

1. Acesse o endereço no Chrome/Edge do seu computador ou Android.
2. Informe um apelido e toque em **CRIAR SALA PRIVADA**.
3. Toque em **COPIAR LINK** no lobby e envie para os amigos.
4. Cada pessoa abre esse link, informa seu nome, toca em **ENTRAR COM CÓDIGO** e escolhe um dos cinco agentes livres.
5. Todos tocam em **ESTOU PRONTO**. O criador clica em **INICIAR TRANSMISSÃO**.
6. Jogar! Cada pessoa escolhe sua própria carta depois de cada onda.

### Testar antes de publicar (opcional)

```bash
npm run dev
```

Abra o endereço local mostrado, normalmente `http://localhost:8787`, no computador. Para amigos em outros endereços de internet, o jogo precisa estar **publicado**. Abrir o HTML pelo Gerenciador de Arquivos do Android não é suficiente para o modo online.

## Publicar só com Android (opcional, mais técnico)

Se você não tiver um PC, existe a possibilidade de usar **Termux** (ambiente de terminal no Android). Instale o aplicativo de uma fonte confiável; no Termux, instale Node.js e um descompactador, autorize acesso à pasta Downloads e use os mesmos comandos `npm install`, `npx wrangler login` e `npm run deploy`. O fluxo de login no navegador pode exigir ajustes no Android; caso tenha dificuldade, é mais simples realizar a publicação inicial em um computador.

## Atualizar o jogo depois

- Para mudar o visual, menu, HUD e controles: `public/index.html`, `public/style.css`, `public/client.js`.
- Para alterar regras do combate, cartas e inimigos: `src/game.js`.
- Para mudar o servidor de salas e WebSocket: `src/index.js`.
- Para adicionar novas artes, músicas e mapas: `public/assets/`, `public/audio/`.
- Para publicar alterações novamente, dentro da mesma pasta: `npm run deploy`.

**Importante:** o código da sala é um segredo simples para compartilhar com amigos, não é um sistema de senha ou autenticação robusta. Não publique o link da sala em grupos públicos. O servidor suporta salas diferentes com códigos diferentes, mas foi dimensionado para grupos pequenos. Consulte os limites da Cloudflare para evitar cobranças ou erros por excesso de uso.

## Solucionar problemas

- **Não abre a sala:** confirme que você acessou um endereço `https://...workers.dev`, e não um arquivo `.html` local; verifique o código de 8 caracteres.
- **A sala está cheia:** existem cinco personagens reservados; crie outra sala.
- **O botão INICIAR está cinza:** cada agente conectado precisa escolher um personagem e clicar em ESTOU PRONTO.
- **A música não toca:** toque no botão ♫ ou na tela; navegadores móveis bloqueiam reprodução automática antes de uma interação.
- **A internet caiu:** volte à página usando o mesmo navegador e o mesmo código. A reconexão depende de o token local ainda existir e de o servidor manter a sessão.
- **Deu erro no deploy:** confira se a versão de Node.js é LTS recente e se `npm install` e `npx wrangler login` foram executados; verifique as instruções atuais da Cloudflare para Durable Objects SQLite.

Feito para desenvolvermos novas fases, mapas, puzzles cooperativos e história multiplayer no mesmo projeto.
