# Projeto Sorriso Online V12.14 — Último Programa

## Conteúdo
- Campanha cooperativa para até cinco jogadores, compartilhando pistas, salas e eventos.
- Documento: aparece só para o jogador que encontrou; depois permanece nos registros da equipe. O início do confronto dos guardas espera a leitura do segundo papel ou um prazo de segurança.
- 2008: perseguição do ocultista, cinco memórias, arena do porão e cinco marcos cooperativos.
- 2025: fuga do mesmo ocultista, Sala das Máscaras, cinco selos de Telópsia, Confessor e o chefe final em três fases.
- Sala de máscaras com arte baseada na sala enviada e transição visual de colocação da máscara; a arte da máscara Lunar é provisória até chegar uma referência.
- Quatro músicas enviadas pelo criador: Living in the Dark (exploração, volume baixo), Fuga Desesperada (perseguições), Sangue 8-bit (combate comum) e Gal 8-bit (chefe final). A OST da Relíquia de Energia permanece no modo Sobrevivência.
- Modo Sobrevivência original preservado.

## Instalar no Codespaces e publicar no mesmo site
1. Envie o arquivo ZIP ao repositório GitHub, na raiz.
2. Na área de trabalho do Codespaces execute, um comando por vez:

    cd /workspaces/projeto-sorriso-online
    git pull --ff-only
    unzip -oq Projeto_Sorriso_Online_V12_14_Completo.zip
    cd Projeto_Sorriso_Online_V12
    npm install
    npm run check
    npm test
    npm run deploy

O comando `npm run deploy` publica de fato na Cloudflare. Para testar sem publicar, rode `npm run dev`, depois abra a aba PORTS e a porta 8787 como Private.

Se já possuir a V12.13 completa instalada, pode enviar e extrair apenas o ZIP de atualização `Projeto_Sorriso_Online_V12_14_Terror_Campanha.zip`, mantendo a mesma pasta interna `Projeto_Sorriso_Online_V12`.

## Controles
- PC: WASD ou setas; E para interagir; clique diretamente no objeto iluminado para caminhar até ele; J para abrir Pistas.
- Celular: joystick e botão INTERAGIR; toque nos objetos iluminados para caminhar até eles; o botão de esquiva também funciona na perseguição.
- Papéis: a pessoa que coletou fecha em GUARDAR NAS PISTAS; todos podem consultar a descoberta pelo botão PISTAS.

## Observações de qualidade
- 55 testes automatizados de regras, interface, música e fluxo passaram; verificações de navegador simulado em PC, celular horizontal e vertical passaram. Não representa teste em cinco aparelhos reais ou garantia de ausência de bugs.
- O jogo mantém uma única sala de até cinco pessoas por código; reconexão e duração das sessões dependem da hospedagem.
- A nova arte e a música de terceiros foram integradas a pedido do criador. Antes de disponibilizar faixas/gravações ao público, é necessário verificar as permissões e licenças adequadas. Pode remover os quatro MP3s em `public/audio/` e trocar os nomes por áudios próprios se necessário.
- A história termina com um gancho para continuar na mesa de RPG. Este pacote é um capítulo cooperativo expandido, não uma campanha com múltiplos capítulos completos.
