# PROJETO SORRISO ONLINE — V12.10 | PESADELO IMPLACÁVEL + OST EXCLUSIVA DOS CHEFES

Essa atualização foi preparada sobre a V12.9 completa. A pasta interna mantém o nome `Projeto_Sorriso_Online_V12` de propósito: é a mesma aplicação publicada na Cloudflare, sem precisar criar outro servidor.

## Mudanças
- Modo Normal preservado.
- Pesadelo: inimigos com mais PV (+95% antes do crescimento com cartas), dano (+55%) e velocidade (+10%); mais inimigos especiais, atiram e atacam com menor intervalo.
- O crescimento de PV dos inimigos no Pesadelo acompanha melhor as cartas acumuladas. Não foram aumentados os limites de 18 inimigos e 165 tiros simultâneos.
- Cartas de dano, projéteis e vida no Pesadelo têm limites para evitar combinações invencíveis. Tenacidade concede até +25 de PV máximo por carta, no máximo +240 acima do PV base; ao atingir o limite vira cura +20 PV. A habilidade curativa do Lunar também foi equilibrada.
- No Pesadelo, a recuperação automática entre ondas é menor. As curas verdes no chão permanecem, como na V12.6.
- Durante a luta contra **qualquer chefe**, a música própria desse chefe tem prioridade. O ritual supremo "Transmissão Zero" ainda acontece visualmente e causa dano, mas não troca nem interrompe a OST. A Relíquia usa a música fornecida para a V12.8 nas três fases e na introdução.
- Permanece a escolha de cartas em 10 segundos, atraso de 3 segundos antes das cartas, arena da Relíquia e coop de cinco agentes.

## Como instalar sem perder seu site
1. Envie **somente um dos ZIPs** ao GitHub, para a raiz do repositório `Davis546/projeto-sorriso-online`, com Add file → Upload files → Commit changes.
2. No Codespaces, use os comandos abaixo (um por vez):

```bash
cd /workspaces/projeto-sorriso-online
git pull --ff-only
unzip -oq Projeto_Sorriso_Online_V12_10_Pesadelo_OST.zip
grep -o 'V12.10 PESADELO IMPLACÁVEL' Projeto_Sorriso_Online_V12/public/index.html
cd Projeto_Sorriso_Online_V12
npm run check
npm test
npm run deploy
```

Se você enviou o ZIP **completo**, use `Projeto_Sorriso_Online_V12_10_Completo.zip` no comando `unzip`. **Não misture os dois no mesmo processo.**

3. Confirme que apareceu `Deployed`. Atualize a página do Chrome com Ctrl+Shift+R. Crie uma sala nova e selecione Pesadelo, pois a dificuldade é definida na criação da sala.

## Testes e limites
36 testes automáticos de servidor/regras/áudio aprovados. O ambiente automatizado bloqueou a abertura em navegador, então o áudio e o desempenho precisam ser conferidos numa partida real no Chrome.

**Direitos de uso:** a OST `Invasion (from BLEACH) — Metal Cover` foi fornecida pelo usuário. Para distribuir uma gravação musical de terceiros publicamente, obtenha as permissões necessárias dos detentores dos direitos.
