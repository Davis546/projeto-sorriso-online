# Projeto Sorriso Online V12.8 — Trilha personalizada da Relíquia

A música enviada pelo usuário foi integrada à batalha da Relíquia de Energia (onda 20 e demais aparições). Inicia na introdução especial; continua durante a luta; troca pela trilha normal ao finalizar. O botão de música continua funcionando.

**Direitos autorais:** a trilha é o cover de “Invasion (from BLEACH)” por Rocco Minichiello, baseada em obra de terceiros. Enviar ao usuário e integrar tecnicamente ao projeto não concede autorização para reproduzir ou distribuir a gravação em um site público. Confirme as licenças e permissões necessárias antes de publicar online.

## Publicação
Envie o ZIP da atualização ao repositório do GitHub. No Codespaces, na raiz do repositório:

```bash
git pull --ff-only
unzip -oq Projeto_Sorriso_Online_V12_8_OST_Reliquia.zip
cd Projeto_Sorriso_Online_V12
npm run check && npm test && npm run deploy
```

Caso o terminal já esteja na pasta do jogo, volte para a raiz antes de descompactar.
Verifique que aparece **V12.8 OST DA RELÍQUIA** na tela do jogo, depois atualize a página do Chrome.
