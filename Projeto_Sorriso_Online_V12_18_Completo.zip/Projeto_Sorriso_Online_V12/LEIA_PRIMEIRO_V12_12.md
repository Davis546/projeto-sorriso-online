# Projeto Sorriso V12.12 — CAMPANHA MOBILE

Esta versão prioriza o Capítulo 1 cooperativo de 1 a 5 jogadores em telefones Android/iOS sem afetar a Sobrevivência.

## Correções reais
- Corrigido bug de nomenclatura no cliente: o servidor envia `story.near` e a V12.11 tentava usar `story.ne`; isso desativava o botão **INTERAGIR** e escondia a caixa do terminal. Agora o botão habilita perto da estação, inclusive ao voltar de uma luta.
- Corrigida janela de documentos que podia interceptar toques enquanto oculta por conflito entre CSS e atributo `hidden`. Fechamento por botão, Esc e toque fora.
- Reinicialização de controles após uma luta e perda de foco; melhorias no joystick, botões, área segura e posicionamento responsivo em telas horizontais e verticais.
- Diário simplificado com objetivo, contagem de provas/memórias/máscaras/selos e registros compartilhados; o painel de investigação é ocultado durante as batalhas para não tampar a arena.
- Cinco novos sprites PNG pixel art sem máscara, integrados à campanha e seleção. Após recuperar a máscara, o sprite de agente mascarado é usado novamente. Os PNGs são pequenos e fáceis de carregar.

## História e cooperação
- Reforçada a verdade: Sol, apresentador, obrigou **cinco adolescentes amigos** a lutarem na arena; o ritual de Telópsia aprisionou as **essências** deles nas máscaras.
- Depois de pegar as máscaras, uma nova etapa **Sincronia dos Cinco Selos** exige que cada agente conectado ative seu símbolo, antes de surgir O Confessor.
- O progresso e documentos continuam sincronizados por sala. Em testes solo, o jogador consegue concluir com seu personagem sem precisar de quatro contas de teste.

## Atualizar no GitHub Codespaces (sem publicar)
1. Adicione o ZIP de atualização ao repositório `Davis546/projeto-sorriso-online` pelo navegador do GitHub e faça o commit.
2. No terminal do Codespaces:

```sh
cd /workspaces/projeto-sorriso-online
git pull --ff-only
unzip -oq Projeto_Sorriso_Online_V12_12_Campanha_Mobile.zip
cd Projeto_Sorriso_Online_V12
npm install
npm run check
npm test
npm run dev
```

3. Na guia **Ports** do Codespaces abra a porta **8787** (visibilidade **Private**). Use a URL encaminhada do Codespaces para testar. Isso **não** altera o jogo público da Cloudflare.
4. Para publicar quando você desejar, pare `npm run dev` com Ctrl+C e execute `npm run deploy`. A versão pública só muda depois de um deploy explícito.

**Se estiver usando o ZIP completo**, use o nome `Projeto_Sorriso_Online_V12_12_Completo.zip` no comando `unzip`.

## Validação e limites
- Testes Node de regras, cenários com 5 jogadores, música e regressões de UI.
- Navegador Chromium simulado em resoluções de celular **844×390** e **390×844**: teste do botão de interação, retorno da luta e abertura do terminal sem erros de JavaScript.
- Não houve validação end-to-end com cinco celulares físicos ao mesmo tempo. Testes automatizados não garantem ausência de bugs em todos os aparelhos.
- A gravação da OST de terceiros, enviada anteriormente, permanece no pacote completo. Para distribuí-la publicamente, verifique os direitos de uso.
