# Projeto Sorriso Online V12.15 — Corrida, perseguidor animado e colisões

- Perseguidor animado: imagem 4×4 de movimento pixelado em vez da foto rígida no mapa.
- Corrida: segure Shift no PC ou o botão CORRER no celular. Consome fôlego (100), recarrega quando desacelera.
- INTERAGIR: distância aumentada e clique/toque mais generoso; ao tocar no botão de longe o personagem caminha até a pista.
- Chefes: o dano de CONTATO só acontece bem perto, não à distância. Ataques de área e projéteis continuam perigosos quando telegráficos acertam.
- Nome dos jogadores subido para não cobrir a cabeça, animação leve de caminhada dos agentes.
- Grito curto original no jumpscare (volume controlado). Trilha baixa, som de tiro na frente.
- Mantém 5 jogadores online, músicas, documentos compartilhados e campanha.

Para instalar: extraia o ZIP completo na raiz do repositório, entre na pasta Projeto_Sorriso_Online_V12 e rode npm install, npm run check, npm test e npm run deploy. A publicação afeta o site público, portanto teste antes se desejar.
