# Projeto Sorriso Online — V12.13 | Campanha: Interação e Pixel Art

## Correções de gameplay
- A Estação VHS e o Projetor agora avançam por interação simples. NÃO existe mais senha no terminal.
- Use E (PC), INTERAGIR (PC/celular) ou toque/clique no símbolo luminoso da estação.
- Ampliação do raio de interação com validação pelo servidor, sem bloqueios por atraso da interface.
- Ao acabar o combate dos guardas, o modo exploração restaura a entrada dos jogadores e as pistas pendentes.
- Painel de pistas compacto e diário com registros compartilhados (gravações, relatórios, depoimentos).
- O Capítulo 1 mantém cinco jogadores, passado de 2008, Telópsia e os cinco selos cooperativos.

## Identidade visual
- Retratos dos agentes ORIGINAIS na seleção (presentes desde a versão anterior).
- Cinco sprites novos dos agentes sem máscara, usados no PRESENTE.
- Cinco sprites distintos dos adolescentes, usados somente nos flashbacks de 2008.
- Mapas mais detalhados da TV Paulista, do passado e da Sala das Máscaras; continuam leves em WebP.
- Arte pixelada diferente para Sol Sorridente, Diretora, TV e Confessor.

## Teste privado no GitHub Codespaces
1. Envie o ZIP completo ao GitHub (Add file > Upload files > Commit changes). Não precisa apagar o anterior.
2. Abra Codespaces e cole no terminal:

    cd /workspaces/projeto-sorriso-online
    git pull --ff-only
    unzip -oq Projeto_Sorriso_Online_V12_13_Completo.zip
    cd Projeto_Sorriso_Online_V12
    npm install
    npm run check
    npm test
    npm run dev

3. Na aba PORTS, abra a porta 8787 como **Private**. Use o link encaminhado, não 127.0.0.1 do seu celular.
4. Teste a campanha sozinho ou com até cinco jogadores em uma nova sala. A versão pública não muda.
5. Para publicar depois, pare o servidor de desenvolvimento (Ctrl+C) e execute `npm run deploy`.

## Se preferir a atualização pequena
- Ela é feita para ser extraída SOBRE a versão V12.12 completa já instalada.
- O nome da pasta interna CONTINUA `Projeto_Sorriso_Online_V12`.
- Substitua no comando `unzip` o nome do pacote pelo ZIP pequeno `Projeto_Sorriso_Online_V12_13_Corrigir_Interacao_Arte.zip`.

## Validação / limites
- `npm run check` e 51 testes de regras, renderização estática e integração de UI passaram.
- Playwright/Chromium com WebSocket simulado: PC 1280×720, celular horizontal 844×390 e vertical 390×844; interação por botão, por clique/toque no objeto, pós-combate e diário.
- Ainda precisa de teste real com cinco celulares conectados. Não podemos garantir ausência de bugs em todos os modelos.
- Áudio de terceiros incluído no jogo completo por ter sido enviado pelo usuário anteriormente; distribuição pública depende dos direitos de uso da gravação.
