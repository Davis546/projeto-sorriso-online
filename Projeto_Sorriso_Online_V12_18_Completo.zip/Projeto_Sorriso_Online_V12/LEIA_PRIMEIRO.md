# Projeto Sorriso V12.16 — Perseguição sem dano de susto

- O ocultista persegue o jogador mais próximo mais depressa nas cenas de 2008 e 2025.
- O jogador pode fugir segurando CORRER (Shift no PC / botão no celular), consumindo fôlego.
- Quando o ocultista alcança um agente, há jumpscare/grito e recuo, mas **nenhuma perda de PV**.
- O indicador MEDO é apenas visual: chegar a 100 não encerra a campanha.
- Golpes e ataques REAIS de inimigos nas lutas continuam causando dano normalmente.
- Preserva o modo Sobrevivência, campanha cooperativa, OSTs, cartas, curas e chefes.

## Atualização no Codespaces (sobre a V12.15)
1. Adicione `Projeto_Sorriso_Online_V12_16_Perseguicao_Sem_Dano.zip` ao GitHub (Upload files e Commit changes).
2. No terminal da pasta do repositório, execute `git pull --ff-only`.
3. Execute `unzip -oq Projeto_Sorriso_Online_V12_16_Perseguicao_Sem_Dano.zip`.
4. Entre na pasta `Projeto_Sorriso_Online_V12` e execute `npm run check`, `npm test` e `npm run deploy`.

**Atenção:** faça uma sala nova depois de publicar para receber as regras novas do servidor. Faça um teste com apenas um agente antes de chamar os cinco amigos.
