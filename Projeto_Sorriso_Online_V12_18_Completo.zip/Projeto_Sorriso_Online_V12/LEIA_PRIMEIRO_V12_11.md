# Projeto Sorriso Online V12.11 — Campanha Cooperativa (Capítulo 1)

Este pacote acrescenta a primeira missão de campanha online ao jogo de sobrevivência V12.10. O progresso do capítulo, as provas recolhidas, as memórias, as máscaras e o combate são sincronizados pelo mesmo Durable Object da sala para até cinco pessoas. A Sobrevivência permanece como modo separado.

## Conteúdo jogável do Capítulo 1

- TV Paulista (2025): explorar a recepção, recolher a Fita VHS 03, o Arquivo 17 e ouvir Sandra.
- Emboscada de três guardas da transmissão entre as pistas.
- Primeiro enigma coletivo: a senha de quatro números do terminal.
- Memórias de 2008: controlar os cinco personagens sem máscara, fugir do Vigia, investigar cinco lembranças — Solar, Ritual, Alvo, Feras, Lunar.
- Segundo enigma: o ano do encerramento da TV Paulista no projetor.
- Sala das Máscaras: cada agente presente recolhe sua máscara; a lore apresenta o ritual secreto de Telópsia.
- O Confessor: chefe da sala, acompanhado de criaturas, usando os controles de combate do jogo online.
- Conclusão do Capítulo 1. As próximas fases de Rua Violeta e Yuri não estão incluídas nesta versão.

## Como jogar

1. Crie uma sala e selecione **CAMPANHA ONLINE** (ou **SOBREVIVÊNCIA** para o modo antigo).
2. Compartilhe o código/link. Há cinco agentes únicos e um máximo de cinco participantes. O líder pode iniciar com menos jogadores para testar o capítulo; para jogar com a equipe completa, junte os cinco antes de começar.
3. Cada jogador escolhe seu agente, confirma **PRONTO** e o líder inicia.
4. Movimento: WASD/setas no PC ou controle virtual no celular. **E** ou **INTERAGIR** perto dos pontos marcados, **J** ou **DOCUMENTOS** para consultar as pistas, formulário numérico para terminais; combate conserva os controles anteriores.
5. As provas pertencem à sala: qualquer um pode encontrá-las e todos podem lê-las. Cada agente recupera sua própria máscara; se houver menos de cinco conectados, os presentes podem continuar.

## Atualização no seu Codespaces

Envie o ZIP de atualização ao repositório GitHub `Davis546/projeto-sorriso-online` usando Add file -> Upload files -> Commit changes. Depois execute, um comando por vez:

```bash
cd /workspaces/projeto-sorriso-online
git pull --ff-only
unzip -oq Projeto_Sorriso_Online_V12_11_Campanha_5_Jogadores.zip
grep -o 'V12.11 CAMPANHA ONLINE' Projeto_Sorriso_Online_V12/public/index.html
cd Projeto_Sorriso_Online_V12
npm run check
npm test
npm run deploy
```

A pasta interna do ZIP continua `Projeto_Sorriso_Online_V12`, para atualizar o mesmo Worker. O endereço `.workers.dev` não muda.

## Limites desta entrega

- Foram validadas as regras e a sincronização de estados com testes Node, além de uma prévia de interface em navegador simulado. **Não foi testado o multiplayer de cinco navegadores reais conectados ao Worker na Cloudflare**; teste em sala nova após publicar.
- Existe um primeiro capítulo jogável, **não a campanha inteira**. Novas salas, chefes e histórias podem ser feitos depois.
- A gravação da OST enviada pelo usuário está no pacote; **a distribuição pública exige as permissões aplicáveis dos titulares de direitos**.
- Cloudflare Workers/Durable Objects têm limites de uso no plano gratuito. Gratuitidade sob os limites do plano não é garantia de execução ilimitada.
