# Projeto Sorriso Online — V12.9 | Relíquia de Energia em 3 fases

Atualização da **V12.8**. Não altera a hospedagem: mantém o Worker e o Durable Object já usados no Cloudflare. A pasta continua com o nome `Projeto_Sorriso_Online_V12` para sobrescrever os arquivos corretos.

## Mudanças

- **Relíquia na onda 20 / 40...:** mais vida (base do chefe 9.200 → 12.800 antes da escala da onda), mais dano e maior velocidade.
- **Fase I, 100%–70%:** raios que marcam jogadores, leque de lasers e orbes radiais.
- **Fase II, abaixo de 70%:** três núcleos protegem o chefe; prisão elétrica, magnetismo e clones explosivos. Destrua os núcleos para causar dano nele novamente.
- **Fase III, abaixo de 32%:** quatro núcleos, ataques mais rápidos, lasers em cruz, espiral de estilhaços, chuva elétrica e colapso dimensional. Entre em uma das **duas zonas seguras** antes da explosão.
- Barra de vida indica fase atual e número de núcleos; mudança de fase tem aviso visual.
- OST da Relíquia da V12.8, mapa dimensional, curas e coop para cinco jogadores preservados.
- Golpes são avisados antes de causar dano, inclusive o colapso final, para não depender apenas de sorte.

## Atualização pequena (recomendada se V12.8 já está instalada)

1. Envie `Projeto_Sorriso_Online_V12_9_Reliquia_3_Fases.zip` para a raiz do repositório GitHub e confirme o commit.
2. Abra o Codespaces e, **na raiz do repositório**, execute:

```bash
cd /workspaces/projeto-sorriso-online
git pull --ff-only
unzip -oq Projeto_Sorriso_Online_V12_9_Reliquia_3_Fases.zip
grep -o 'V12.9 RELÍQUIA 3 FASES' Projeto_Sorriso_Online_V12/public/index.html
cd Projeto_Sorriso_Online_V12
npm run check
npm test
npm run deploy
```

3. Espere a confirmação `Deployed`. No Chrome pressione Ctrl+Shift+R. **Crie uma sala nova** para evitar usar uma partida já em andamento com as regras anteriores.

Se o arquivo enviado foi `Projeto_Sorriso_Online_V12_9_Completo.zip`, substitua somente o nome do ZIP no comando `unzip`.

## Avisos

- Testes automatizados de regras não garantem latência ou FPS em celulares reais. Teste a onda 20 com outros jogadores.
- A música do boss é um cover de obra de terceiros fornecido pelo usuário. Distribuir publicamente a gravação exige autorização/licenças adequadas. A atualização pequena não contém o áudio; ela preserva a música já instalada.
