import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,statSync} from 'node:fs';
const source=readFileSync(new URL('../public/client.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../public/style.css',import.meta.url),'utf8');
const html=readFileSync(new URL('../public/index.html',import.meta.url),'utf8');
test('correcao mobile: botao e terminal usam campo near do servidor',()=>{
 assert.match(source,/const st=w\.story,stage=st\.stage,near=st\.near/);
 assert.match(source,/\$\('interactAction'\)\.disabled=!near/);
 assert.match(source,/stage==='terminal'\|\|stage==='projector'/);
 assert.doesNotMatch(source,/\bst\.ne\b/);
});
test('diario oculto nao intercepta toques, possui fechar e suporta mobile',()=>{
 assert.match(css,/#storyJournal\[hidden\][^\n]+display:none!important/);
 assert.match(source,/\$\('closeJournal'\)\.onclick=\(\)=>toggleJournal\(false\)/);
 assert.match(css,/@media\(orientation:landscape\) and \(max-height:520px\)/);
 assert.match(html,/id="storyProgress"/);
});
test('cinco personagens possuem pixel art sem mascara',()=>{
 for(const name of ['solar','ritual','alvo','feras','lunar']){
  assert.ok(statSync(new URL('../public/assets/campanha-'+name+'.png',import.meta.url)).size>2000);
 }
 assert.match(source,/campaignSprite\[o\.agent\]/);
});
