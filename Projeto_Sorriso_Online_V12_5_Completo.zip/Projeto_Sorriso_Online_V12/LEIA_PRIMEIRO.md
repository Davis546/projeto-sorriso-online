# Projeto Sorriso Online V12.5 — ONDAS RÁPIDAS

Esta atualização usa o mesmo servidor Cloudflare e preserva a V12.4 Ultra Leve.

## Mudanças

- Após cada onda, todos têm **10 segundos** para escolher uma carta (antes: 45 segundos).
- Se um jogador não escolher, o servidor aplica automaticamente a primeira carta oferecida ao acabar o tempo.
- Se todos escolherem antes, a fase de cartas termina imediatamente.
- Pausa entre o fim das cartas e a próxima onda é **1 segundo real** (antes: 2 segundos nominais, que podiam durar muito mais por um erro de contagem).
- Contagem regressiva visível na tela de escolha, sem polling extra de rede.
- Versão 12.5 no menu e no endpoint /api/health.

## Instalação

Envie `Projeto_Sorriso_Online_V12_5_Ondas_Rapidas.zip` à raiz do repositório GitHub (Add file → Upload files → Commit changes).
No terminal do Codespaces execute **uma linha de cada vez**:

```bash
cd /workspaces/projeto-sorriso-online
git pull --ff-only
unzip -oq Projeto_Sorriso_Online_V12_5_Ondas_Rapidas.zip
cd Projeto_Sorriso_Online_V12
npm test
npm run deploy
```

Após `Deployed`, use Ctrl + Shift + R e crie uma sala nova. O jogo mantém o link da Cloudflare.

Observação: o atraso de rede pode causar uma diferença de até aproximadamente 1,5 segundo entre a contagem chegar a zero e o servidor passar de fase. Isso ocorre porque a atualização de estado é acionada por mensagens periódicas dos jogadores. Não se trata de garantia de precisão cronométrica perfeita.

---

# Projeto Sorriso Online V12.4 — ULTRA LEVE (Cloudflare)

Essa versao foi otimizada em cima da V12.3 que voce ja publicou. Mantem a Cloudflare, o mesmo endereco, as salas, os 5 agentes e os chefes.

## O que realmente mudou

- **Mapa pixelizado**: o fundo original de 1536x1024 agora tem versoes de 768x512 (Leve) e 384x256 (ECO), com menos textura na memoria. O mapa original so carrega no modo HD.
- **Leve desde a abertura**, inclusive no PC. O botao do HUD alterna ⚡ -> ECO -> HD -> ⚡.
- **Mais suavidade dos outros personagens e inimigos** entre os pacotes do servidor, com extrapolacao visual curta, sem mudar as regras.
- **Controles com envio imediato** em teclas, clique e joystick, alem da sincronizacao normal. Isso diminui a demora inicial de comandos.
- **FPS e PING visiveis no canto superior direito**, junto com REDE (atualizacoes recebidas por segundo), sem ficar escondidos na barra inferior do Android.
- **Corte de desenhos fora da tela**, reduzindo o numero de sprites e projeteis desenhados quando a camera esta longe.
- **Preferencia de regiao para salas novas**: locationHint 'sam' na Cloudflare, uma sugestao, NAO uma garantia de baixar o ping. A propria documentacao diz que Durable Objects com dica sam podem nascer no leste dos EUA.

## Atualizar via Codespaces no mesmo projeto

1. Envie `Projeto_Sorriso_Online_V12_4_Ultra_Leve.zip` para a raiz do seu repositorio Github e confirme o commit.
2. No terminal do Codespaces, execute **um por vez**:

```bash
cd /workspaces/projeto-sorriso-online
git pull --ff-only
unzip -oq Projeto_Sorriso_Online_V12_4_Ultra_Leve.zip
cd Projeto_Sorriso_Online_V12
npm test
npm run deploy
```

3. No PC, Ctrl+Shift+R. No celular, feche a aba antiga e abra o link novamente.
4. **CRIE UMA SALA NOVA** e confira no jogo o HUD com `PING`, `FPS` e `REDE`.
5. Se FPS ficar proximo de 60 e REDE perto de 8-10/s mas o ping continuar 150ms, o maior limite provavelmente sera a distancia ate o Durable Object ou a taxa de sincronizacao; trocar o mapa ja nao tera muito efeito.

### Limites conhecidos

- O desenho e a posicao visual local ficam mais fluidos, mas os tiros, danos e a partida continuam decididos pelo servidor.
- Nao ha promessa de 60 FPS em todos os celulares ou de ping baixo: dependem de aparelho, conexao e onde Cloudflare aloca a sala.
- O ZIP de atualizacao nao representa o tamanho do jogo todo; ele contem somente arquivos alterados.
- Mudancas visuais nao resolvem atrasos fisicos da rede, e este projeto permanece um prototipo cooperativo para ate cinco pessoas.

---

# Projeto Sorriso Online V12.3 — Fluidez (Cloudflare Free)

Esta atualização **não exige Fly.io, servidor pago nem domínio novo**. Mantém o projeto original Cloudflare Workers + Durable Objects.

Melhorias em relação à V12.2:
- O personagem local responde visualmente a cada quadro, mesmo entre atualizações da rede. O servidor continua controlando combate e posições definitivas.
- O modo leve agora tenta atingir **até 60 FPS**, em vez do limite de 30 FPS.
- Modo **ECO** reduz a resolução interna e limita a 30 FPS nos aparelhos mais lentos.
- Ajuste automático para Leve/ECO após quedas sustentadas de FPS.
- Chefes reutilizam sprites em cache no modo leve, reduzindo o processamento do Canvas.
- Limpeza periódica de posições de inimigos derrotados evita acúmulo de memória.
- Redução na frequência de gravações persistentes durante combates.
- Continua exibindo PING e FPS na tela para diferenciar problemas de conexão e desempenho.

O ZIP de atualização substitui somente os arquivos necessários na mesma pasta `Projeto_Sorriso_Online_V12`. **Não apague a pasta nem crie outro servidor Cloudflare.**

## Atualização pelo GitHub Codespaces

1. Envie `Projeto_Sorriso_Online_V12_3_Fluidez_Gratis.zip` para a raiz do seu repositório pelo GitHub e clique em **Commit changes**.
2. Execute no terminal: 

```bash
cd /workspaces/projeto-sorriso-online
git pull --ff-only
unzip -oq Projeto_Sorriso_Online_V12_3_Fluidez_Gratis.zip
cd Projeto_Sorriso_Online_V12
npm run deploy
```

3. Abra o **mesmo link** do jogo e pressione `Ctrl + Shift + R` no computador para atualizar sem cache.
4. Veja os indicadores `PING` e `FPS`. No HUD, o botão **HD / ⚡ / ECO** alterna os modos.
5. Teste com duas pessoas na mesma sala antes de reunir os cinco.

## Avisos

- A correção melhora a renderização e a previsão local, mas não garante 60 FPS em todo hardware/rede.
- O plano gratuito da Cloudflare tem limites de requisições, CPU e Durable Objects. Confira os limites oficiais no painel.
- O servidor permanece autoritativo; a predição visual local pode sofrer pequenas correções de posição quando o ping estiver muito alto.
- Não confunda o tamanho do ZIP da **correção** com a memória ou o peso do jogo durante a partida.

---

# Atualização V12.2 — Movimento mais responsivo e diagnóstico

Esta atualização conserva o mesmo site, as salas privadas e o servidor Cloudflare.

- Exibe PING (ms) e FPS na parte inferior da tela após entrar na sala.
- Movimento do personagem local previsto visualmente; posição e dano continuam controlados pelo servidor.
- O visor indica se os travamentos vêm de atraso de rede (ping elevado) ou renderização (FPS baixo).
- O ZIP de correção é apenas uma atualização; ele não representa o tamanho total do jogo.
- A alteração de código não comprova desempenho em todos os celulares. Teste com o PC e o celular na mesma sala.

**Instalação**: coloque o ZIP de correção na raiz do seu repositório, faça commit e no Codespaces execute:

```bash
cd /workspaces/projeto-sorriso-online
git pull --ff-only
unzip -oq Projeto_Sorriso_Online_V12_2_Resposta_Rapida.zip
cd Projeto_Sorriso_Online_V12
npm run deploy
```

Em seguida atualize o navegador (Ctrl+Shift+R no computador) e abra uma sala nova para testar. O endereço workers.dev continua igual.

---

**V12.1 — Modo leve para Android:** interface atualizada somente quando necessário, renderização limitada a 30 FPS no celular, resolução reduzida, efeitos de brilho mais leves e menos atualizações completas pela rede. No jogo, toque no botão ⚡/HD para trocar o modo.

# 📺 Projeto Sorriso Online — V12 (2025)

Esta versão é um **protótipo jogável de arena cooperativa online** para até **5 jogadores reais**. Os jogadores entram na mesma sala privada com código, escolhem agentes diferentes e enfrentam ondas, chefes e cartas roguelike em equipe.

## O que já funciona

- Até cinco pessoas conectadas na mesma partida; um Solar, Ritual, Alvo, Feras e Lunar por sala.
- Sala privada por código de 8 caracteres, link de convite, confirmação de pronto e início pelo líder.
- Movimento, tiros, machado de sangue, rituais, habilidades, esquiva e vidas compartilhadas pela simulação do servidor.
- Monstros e três chefes: **Sol Sorridente** (onda 5), **Diretora** (onda 10) e **chefe da TV** (onda 15). A sequência se repete.
- **Transmissão Zero** quando a barra coletiva chega a 100%.
- Após cada onda, cada jogador escolhe sua própria carta roguelike.
- Retorno à sala após desconexão temporária usando o token daquele navegador, enquanto a sessão for recuperável.
- Sprites dos cinco agentes, monstros, arena e trilhas sonoras originais reaproveitadas da V11.
- Controles para PC (WASD/setas + espaço para atacar, E ritual, Shift esquiva, F supremo) e controles na tela para celular.

**Limitações da V12:** a história com Sandra, Yuri, os cinco puzzles e o Confessor **ainda é solo**; está incluída no arquivo `public/historia-v11.html` e acessível pelo menu. A arena multiplayer foi reimplementada como um protótipo de regras compartilhadas. O balanceamento não é idêntico ao combate offline da V11. Ainda não há contas, progressão permanente, voz integrada nem mapa exploratório online. Não foi realizado teste real com cinco aparelhos conectados à Cloudflare.

## Publicar na internet — passo a passo no computador

### 1. Criar uma conta

Entre em [dash.cloudflare.com](https://dash.cloudflare.com/) e crie uma conta gratuita (ou use a que já tem). Não precisa comprar domínio para usar o endereço `*.workers.dev` que a Cloudflare oferece.

### 2. Preparar o computador

Instale **Node.js LTS** em [nodejs.org](https://nodejs.org/). Descompacte `Projeto_Sorriso_Online_V12.zip`. Abra um terminal **dentro** da pasta `Projeto_Sorriso_Online_V12`, onde fica o arquivo `package.json`.

### 3. Instalar as dependências

```bash
npm install
```

### 4. Entrar na Cloudflare

```bash
npx wrangler login
```

Abra o navegador quando solicitado e autorize o login. Se for a primeira vez usando Workers, a Cloudflare poderá pedir que você configure o subdomínio gratuito `workers.dev` na sua conta.

### 5. Publicar o jogo e o servidor juntos

```bash
npm run deploy
```

O terminal deve mostrar o endereço público, parecido com `https://projeto-sorriso-online.SEUSUBDOMINIO.workers.dev`. Esse endereço é seu jogo; **não precisa contratar hospedagem separada**. A sala funciona enquanto o projeto estiver implantado na Cloudflare e dentro dos limites do seu plano.

### 6. Jogar com os amigos

1. Acesse o endereço no Chrome/Edge do seu computador ou Android.
2. Informe um apelido e toque em **CRIAR SALA PRIVADA**.
3. Toque em **COPIAR LINK** no lobby e envie para os amigos.
4. Cada pessoa abre esse link, informa seu nome, toca em **ENTRAR COM CÓDIGO** e escolhe um dos cinco agentes livres.
5. Todos tocam em **ESTOU PRONTO**. O criador clica em **INICIAR TRANSMISSÃO**.
6. Jogar! Cada pessoa escolhe sua própria carta depois de cada onda.

### Testar antes de publicar (opcional)

```bash
npm run dev
```

Abra o endereço local mostrado, normalmente `http://localhost:8787`, no computador. Para amigos em outros endereços de internet, o jogo precisa estar **publicado**. Abrir o HTML pelo Gerenciador de Arquivos do Android não é suficiente para o modo online.

## Publicar só com Android (opcional, mais técnico)

Se você não tiver um PC, existe a possibilidade de usar **Termux** (ambiente de terminal no Android). Instale o aplicativo de uma fonte confiável; no Termux, instale Node.js e um descompactador, autorize acesso à pasta Downloads e use os mesmos comandos `npm install`, `npx wrangler login` e `npm run deploy`. O fluxo de login no navegador pode exigir ajustes no Android; caso tenha dificuldade, é mais simples realizar a publicação inicial em um computador.

## Atualizar o jogo depois

- Para mudar o visual, menu, HUD e controles: `public/index.html`, `public/style.css`, `public/client.js`.
- Para alterar regras do combate, cartas e inimigos: `src/game.js`.
- Para mudar o servidor de salas e WebSocket: `src/index.js`.
- Para adicionar novas artes, músicas e mapas: `public/assets/`, `public/audio/`.
- Para publicar alterações novamente, dentro da mesma pasta: `npm run deploy`.

**Importante:** o código da sala é um segredo simples para compartilhar com amigos, não é um sistema de senha ou autenticação robusta. Não publique o link da sala em grupos públicos. O servidor suporta salas diferentes com códigos diferentes, mas foi dimensionado para grupos pequenos. Consulte os limites da Cloudflare para evitar cobranças ou erros por excesso de uso.

## Solucionar problemas

- **Não abre a sala:** confirme que você acessou um endereço `https://...workers.dev`, e não um arquivo `.html` local; verifique o código de 8 caracteres.
- **A sala está cheia:** existem cinco personagens reservados; crie outra sala.
- **O botão INICIAR está cinza:** cada agente conectado precisa escolher um personagem e clicar em ESTOU PRONTO.
- **A música não toca:** toque no botão ♫ ou na tela; navegadores móveis bloqueiam reprodução automática antes de uma interação.
- **A internet caiu:** volte à página usando o mesmo navegador e o mesmo código. A reconexão depende de o token local ainda existir e de o servidor manter a sessão.
- **Deu erro no deploy:** confira se a versão de Node.js é LTS recente e se `npm install` e `npx wrangler login` foram executados; verifique as instruções atuais da Cloudflare para Durable Objects SQLite.

Feito para desenvolvermos novas fases, mapas, puzzles cooperativos e história multiplayer no mesmo projeto.
