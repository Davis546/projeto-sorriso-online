import test from 'node:test';import assert from 'node:assert/strict';
import {makeRoom,joinRoom,chooseAgent,readyUp,launch,advance,pickCard,setInput,disconnect,snapshot,STATS,CARD_CHOICE_MS,BETWEEN_WAVES_S} from '../src/game.js';
const t=i=>'token_jogador_'+i;
function build(num=5){const w=makeRoom('ABCD2345');const ids=['solar','ritual','alvo','feras','lunar'];for(let i=0;i<num;i++){joinRoom(w,t(i),'Agente '+i);assert.equal(chooseAgent(w,t(i),ids[i]),true);readyUp(w,t(i));}assert.equal(launch(w,t(0)),true);return w;}
test('lobby reserva personagens e limita 5 jogadores',()=>{const w=makeRoom('ABCD2345');for(let i=0;i<5;i++)joinRoom(w,t(i),'Agente '+i);assert.throws(()=>joinRoom(w,t(5),'Excedente'),/SALA_CHEIA/);assert.equal(chooseAgent(w,t(0),'solar'),true);assert.equal(chooseAgent(w,t(1),'solar'),false);assert.equal(chooseAgent(w,t(1),'lunar'),true);});
test('cinco jogadores entram com personagens diferentes e vida própria',()=>{const w=build();assert.equal(w.phase,'fight');assert.equal(w.wave,1);const chars=Object.values(w.players);assert.equal(new Set(chars.map(p=>p.agent)).size,5);assert.equal(w.players[t(2)].maxHp,STATS.alvo.hp);assert.equal(snapshot(w,t(0)).players.length,5);});
test('o servidor controla movimentação, habilidades e dano',()=>{const w=build(2);const p=w.players[t(0)];const x=p.x;setInput(w,t(0),{x:1,y:0,fire:true,skill:true,dash:true});assert.ok(p.skillCd>0);assert.ok(p.dashCd>0);w.lastTime=Date.now()-90;advance(w,Date.now());assert.ok(p.x>x);});
test('cada jogador escolhe sua carta e melhoria fica no agente',()=>{const w=build(2);w.toSpawn=0;w.enemies=[];w.lastTime=Date.now()-90;advance(w,Date.now());assert.equal(w.phase,'cards');assert.equal(w.players[t(0)].choices.length,3);assert.equal(w.players[t(1)].choices.length,3);assert.equal(pickCard(w,t(0),0),true);assert.equal(w.phase,'cards');assert.equal(pickCard(w,t(1),1),true);assert.equal(w.phase,'between');assert.equal(w.players[t(0)].upgrades.length,1);w.between=.01;w.lastTime=Date.now()-80;advance(w,Date.now());assert.equal(w.wave,2);});
test('bosses na onda 5, 10 e 15',()=>{const w=build(1);const found=[];for(let n=1;n<=15;n++){if(w.bossKind)found.push([w.wave,w.bossKind]);w.toSpawn=0;w.enemies=[];w.lastTime=Date.now()-100;advance(w,Date.now());assert.equal(w.phase,'cards');pickCard(w,t(0),0);w.between=.01;w.lastTime=Date.now()-100;advance(w,Date.now());}assert.deepEqual(found,[[5,'sol'],[10,'diretora'],[15,'tv']]);});
test('ataque supremo coletivo usa a barra e atinge monstros',()=>{const w=build(5),p=w.players[t(0)];w.ult=100;const before=w.enemies.map(e=>e.hp);setInput(w,t(0),{ult:true});assert.equal(w.ult,0);assert.ok(w.effects.some(e=>e.t==='ultimate'));assert.ok(w.enemies.every((e,i)=>e.hp<=before[i]));});
test('desconexão de agente mantém vaga para reconexão',()=>{const w=build(1);disconnect(w,t(0));assert.equal(w.players[t(0)].connected,false);joinRoom(w,t(0),'Agente 0');assert.equal(w.players[t(0)].connected,true);assert.equal(w.players[t(0)].agent,'solar');});

test('10 segundos de escolha de carta, depois carta automática e 1 segundo de pausa',()=>{
 const w=build(3);
 w.toSpawn=0;w.enemies=[];w.lastTime=Date.now()-90;advance(w,Date.now());
 assert.equal(w.phase,'cards');
 assert.ok(Math.abs(w.cardDeadline-Date.now()-CARD_CHOICE_MS)<1000);
 assert.equal(pickCard(w,t(0),1),true);
 assert.equal(w.phase,'cards');
 // Ninguem precisa esperar o jogador ausente depois dos dez segundos.
 w.lastTime=w.cardDeadline-100;
 advance(w,w.cardDeadline-1);
 assert.equal(w.phase,'cards');
 advance(w,w.cardDeadline);
 assert.equal(w.phase,'between');
 assert.equal(w.between,BETWEEN_WAVES_S);
 for(const p of Object.values(w.players)){
  assert.equal(p.chosen,true);
  assert.equal(p.upgrades.length,1);
 }
 assert.equal(pickCard(w,t(1),0),false);
 w.lastTime=Date.now()-80;
 w.between=.02;
 advance(w,Date.now());
 assert.equal(w.phase,'fight');
 assert.equal(w.wave,2);
});
test('pausa de 1 segundo usa tempo real e nao tempo artificial do simulador',()=>{
 const w=build(1);w.toSpawn=0;w.enemies=[];w.lastTime=Date.now()-100;advance(w,Date.now());
 assert.equal(pickCard(w,t(0),0),true);
 assert.equal(w.phase,'between');
 const afterOneSecond=Date.now()+1100;w.lastTime=afterOneSecond-1100;
 advance(w,afterOneSecond);
 assert.equal(w.phase,'fight');
 assert.equal(w.wave,2);
});
test('quando todos escolhem antes do prazo, nao espera 10 segundos',()=>{
 const w=build(2);w.toSpawn=0;w.enemies=[];w.lastTime=Date.now()-90;advance(w,Date.now());
 assert.equal(pickCard(w,t(0),0),true);
 assert.equal(pickCard(w,t(1),2),true);
 assert.equal(w.phase,'between');
 assert.equal(w.between,1);
});
