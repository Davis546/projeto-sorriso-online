import {AGENTS,createArt,renderBoss} from './art.js';
const $=id=>document.getElementById(id), canvas=$('arena'),ctx=canvas.getContext('2d',{alpha:false});
const W=1536,H=1024,BOUND={l:155,r:1380,t:310,b:900}, HERO={solar:'🎯',ritual:'🔮',alvo:'🪓',feras:'🔫',lunar:'🌙'},NAME={solar:'SOLAR',ritual:'RITUAL',alvo:'ALVO',feras:'FERAS',lunar:'LUNAR'};
// Mapas pixelizados: baixa memoria e texturas no modo leve, HD so por escolha manual.
const ART=createArt(),bgLite=new Image(),bgEco=new Image(),bgHD=new Image();
bgLite.decoding='async';bgEco.decoding='async';bgHD.decoding='async';bgLite.src='/assets/arena-lite.webp';
function mapForQuality(){
 if(ecoGraphics){if(!bgEco.getAttribute('src'))bgEco.src='/assets/arena-eco.webp';return bgEco.naturalWidth?bgEco:bgLite;}
 if(!lowGraphics){if(!bgHD.getAttribute('src'))bgHD.src='/assets/arena.jpg';return bgHD.naturalWidth?bgHD:bgLite;}
 return bgLite;
}
const portraits={};AGENTS.forEach(a=>{portraits[a.id]=new Image();portraits[a.id].src='/assets/'+a.id+'.jpg';});
let ws=null,world=null,roomCode='',me='',offline=false,retries=0,resizeW=0,resizeH=0,dpr=1,musicOn=true,lastMusic='',phaseOld='',messageOld='',choicesOld='',lastAt=0,shake=0,musicLockedUntil=0;
// Qualidade reduzida por padrão em telas sensíveis ao toque: renderiza menos pixels e efeitos.
let lowGraphics=true; // Priorizar fluidez no PC e no celular; HD opcional no botão.
let ecoGraphics=false, lowFpsSeconds=0, lastQualityAdjust=0;
const framePositions=new Map(),netVelocity=new Map();
const limit=(n,a,b)=>Math.max(a,Math.min(b,n));

let hudLast=0,lobbyLast='',partyLast='',stateAt=performance.now(),pingMs=null,shownFps=0,framesSeen=0,fpsStart=performance.now(),snapCount=0,snapRate=0;

const keys=new Set(),touch={x:0,y:0,fire:false},pending={skill:false,dash:false,ult:false},visualPos=new Map(),audio=new Audio();audio.loop=true;audio.volume=.21;audio.preload='auto';
const urls={lobby:'lobby',fight:'waves',cards:'between',between:'between',over:'defeat'};
const randomCode=()=>{const alpha='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',arr=new Uint8Array(8);crypto.getRandomValues(arr);return [...arr].map(n=>alpha[n%alpha.length]).join('');};
const sending=v=>{if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(v));};
function playMusic(track){if(Date.now()<musicLockedUntil&&track!=='ultimate')return;if(lastMusic===track)return;lastMusic=track;audio.src='/audio/'+track+'.mp3';if(musicOn){audio.play().catch(()=>{});} }
function userGesture(){if(musicOn&&audio.paused)audio.play().catch(()=>{});}
function showStatus(t){$('entryStatus').textContent=t;}
function readPong(msg){if(typeof msg.t!=='number'||!Number.isFinite(msg.t))return;const raw=performance.now()-msg.t;if(raw<0||raw>30000)return;pingMs=pingMs===null?raw:pingMs*.75+raw*.25;}
function updateStats(ts){
 if(ts-fpsStart<1000)return;
 shownFps=Math.round(framesSeen*1000/Math.max(1,ts-fpsStart));framesSeen=0;fpsStart=ts;
 snapRate=snapCount;snapCount=0;
 const label=$('netStats');label.textContent=(pingMs===null?'PING —':'PING '+Math.round(pingMs)+'ms')+'  |  FPS '+(world?.phase==='fight'?shownFps:'—')+'  |  REDE '+snapRate+'/s'+(ecoGraphics?'  ECO':'');
 label.dataset.state=pingMs===null?'unknown':pingMs>180?'slow':'good';
 // Não travar todos os celulares em 30 FPS: reduzir pixels primeiro, FPS por último.
 if(world?.phase==='fight' && document.visibilityState==='visible'){
  if(shownFps<38)lowFpsSeconds++;else lowFpsSeconds=0;
  if(lowFpsSeconds>=3 && ts-lastQualityAdjust>5000){
   if(!lowGraphics){lowGraphics=true;ecoGraphics=false;showAnn('⚡ QUALIDADE LEVE AUTOMÁTICA');}
   else if(!ecoGraphics){ecoGraphics=true;showAnn('⚡ MODO ECONÔMICO ATIVADO');}
   lowFpsSeconds=0;lastQualityAdjust=ts;qualityLabel();scale();
  }
 }
}
setInterval(()=>{if(ws?.readyState===WebSocket.OPEN)sending({type:'ping',t:performance.now()});},3000);

function connect(create){const name=$('nickname').value.trim().slice(0,18)||'Agente';const code=(create?randomCode():$('roomInput').value.trim().toUpperCase());
 if(!/^[A-HJ-NP-Z2-9]{8}$/.test(code)){showStatus('Digite um código de sala com 8 letras/números.');return;}
 roomCode=code;history.replaceState(null,'','?sala='+code);let token=sessionStorage.getItem('sorriso_token_'+code);if(!token){token=crypto.randomUUID();sessionStorage.setItem('sorriso_token_'+code,token);}me=token;
 const params=new URLSearchParams({code,token,name});if(create)params.set('create','1');const scheme=location.protocol==='https:'?'wss':'ws';
 try{ws=new WebSocket(scheme+'://'+location.host+'/api/ws?'+params.toString());}catch{showStatus('Não foi possível abrir a conexão. Publique o projeto com servidor WebSocket.');return;}
 showStatus('Conectando à transmissão...');offline=false;
 ws.onopen=()=>{retries=0;showStatus('Conectado!');userGesture();};
 ws.onmessage=ev=>{let data;try{data=JSON.parse(ev.data)}catch{return;}if(data.type==='state')consume(data);else if(data.type==='chat')addChat(data.name,data.text);else if(data.type==='pong')readPong(data);};
 ws.onerror=()=>{if(!world)showStatus('A sala não abriu. Verifique o código e o servidor.');};
 ws.onclose=e=>{if(offline)return;if(!world){showStatus('Conexão recusada. A sala pode não existir, estar cheia ou já ter começado.');return;}
  showAnn('CONEXÃO PERDIDA • RECONECTANDO');if(++retries<9)setTimeout(()=>{if(!offline){let p=new URLSearchParams({code,token,name});const scheme=location.protocol==='https:'?'wss':'ws';ws=new WebSocket(scheme+'://'+location.host+'/api/ws?'+p);const old=ws;ws.onopen=()=>{retries=0;showAnn('RECONEXÃO CONCLUÍDA');};ws.onmessage=ev=>{try{const d=JSON.parse(ev.data);if(d.type==='state')consume(d);else if(d.type==='chat')addChat(d.name,d.text);else if(d.type==='pong')readPong(d)}catch{}};ws.onclose=()=>{if(!offline)connectReconnect(name,code,token)};ws.onerror=()=>{};}},1800);
 };
}
function connectReconnect(name,code,token){if(offline||retries>=9)return;retries++;setTimeout(()=>{const p=new URLSearchParams({code,token,name}),scheme=location.protocol==='https:'?'wss':'ws';try{ws=new WebSocket(scheme+'://'+location.host+'/api/ws?'+p);}catch{return;}ws.onmessage=e=>{try{const d=JSON.parse(e.data);if(d.type==='state')consume(d);else if(d.type==='chat')addChat(d.name,d.text);else if(d.type==='pong')readPong(d)}catch{}};ws.onopen=()=>{retries=0;showAnn('DE VOLTA AO SINAL!');};ws.onclose=()=>connectReconnect(name,code,token);},1900);}
function announceIfChanged(w){if(w.phase!==phaseOld){phaseOld=w.phase;const labels={lobby:'SALA ABERTA',fight:'GRAVAÇÃO INICIADA',cards:'ESCOLHA UMA CARTA',between:'PRÓXIMA ONDA',over:'SINAL PERDIDO'};showAnn(labels[w.phase]);}
 if(w.message!==messageOld&&w.phase==='fight'){messageOld=w.message;showAnn(w.message);}
 for(const effect of w.effects||[]){if(effect.t==='ultimate'&&effect.id!==lastAt){lastAt=effect.id;showAnn('★ TRANSMISSÃO ZERO ★');shake=18;musicLockedUntil=Date.now()+2600;playMusic('ultimate');setTimeout(()=>{musicLockedUntil=0;if(world){const b=world.enemies.find(e=>['sol','diretora','tv'].includes(e.kind));playMusic(b?(b.kind==='tv'?'alvo':b.kind):'waves');}},2700);}}
}
let annTimeout=null;function showAnn(t){const el=$('flashAnnouncement');el.textContent=t;el.classList.add('show');clearTimeout(annTimeout);annTimeout=setTimeout(()=>el.classList.remove('show'),2300);}
let lastPrune=0;
function consume(w){
 const now=performance.now();snapCount++;
 // Calcular velocidade usando duas fotos do servidor; apenas para desenhar entre pacotes.
 if(world?.phase==='fight'&&w.phase==='fight'){
  const elapsed=limit((now-stateAt)/1000,.045,.40);
  const old=new Map([...world.players,...world.enemies].map(o=>[o.token??o.id,o]));
  for(const o of [...w.players,...w.enemies]){
   const key=o.token??o.id,prev=old.get(key);if(!prev)continue;
   const dx=o.x-prev.x,dy=o.y-prev.y,dist=Math.hypot(dx,dy);
   if(dist>125){netVelocity.delete(key);continue;}
   const former=netVelocity.get(key),rawX=limit(dx/elapsed,-480,480),rawY=limit(dy/elapsed,-480,480);
   const blended=former?{vx:former.vx*.2+rawX*.8,vy:former.vy*.2+rawY*.8}:{vx:rawX,vy:rawY};
   netVelocity.set(key,blended);
  }
 }

 // Sincronizar posição local apenas quando chega um novo pacote, preservando movimento imediato.
 const myself=w.players?.find(p=>p.token===me);
 const predicted=visualPos.get(me);
 if(w.phase==='fight'&&myself&&myself.hp>0&&predicted){
  const m=getMove(),speed=limit(Number(myself.speed)||220,0,700);
  const latency=limit((pingMs??90)/2000+.015,.02,.13);
  const targetX=limit(myself.x+m.x*speed*latency,BOUND.l+22,BOUND.r-22);
  const targetY=limit(myself.y+m.y*speed*latency,BOUND.t+22,BOUND.b-22);
  const dx=targetX-predicted.x,dy=targetY-predicted.y;
  if(Math.hypot(dx,dy)>110){predicted.x=targetX;predicted.y=targetY;predicted.corrX=predicted.corrY=0;}
  else {predicted.corrX=dx;predicted.corrY=dy;}
 }
 if(now-lastPrune>3500){
  const live=new Set([...(w.players||[]).map(p=>p.token),...(w.enemies||[]).map(e=>e.id)]);
  for(const id of visualPos.keys())if(!live.has(id)){visualPos.delete(id);netVelocity.delete(id);}
  lastPrune=now;
 }
 world=w;stateAt=now;roomCode=w.code;announceIfChanged(w);$('entry').hidden=true;
 const lobby=w.phase==='lobby',cards=w.phase==='cards',over=w.phase==='over';$('lobby').hidden=!lobby;$('cards').hidden=!cards;$('end').hidden=!over;$('hud').hidden=lobby||over;$('controls').hidden=lobby||cards||over||w.phase==='between';$('gameChat').hidden=lobby||over;
 if(lobby){const sig=JSON.stringify([w.host,w.players.map(p=>[p.token,p.agent,p.ready,p.connected])]);if(sig!==lobbyLast){lobbyLast=sig;renderLobby(w);}playMusic('lobby');}else if(cards){renderCards(w);playMusic('between');}else if(over){$('endSummary').textContent='O esquadrão chegou até a onda '+w.wave+'. Tentem uma build nova e voltem ao estúdio.';$('again').hidden=!w.host;playMusic('defeat');}
 else {if(performance.now()-hudLast>190 || w.phase!==phaseOld){hudLast=performance.now();renderHud(w);}const b=w.enemies.find(e=>['sol','diretora','tv'].includes(e.kind));if(w.phase==='between')playMusic('between');else playMusic(b?b.kind==='tv'?'alvo':b.kind:'waves');}
}
function renderLobby(w){$('code').textContent=w.code;$('start').hidden=!w.host;
 const mine=w.players.find(p=>p.token===me);$('ready').textContent=mine?.ready?'✓ PRONTO — CANCELAR':'ESTOU PRONTO';$('ready').disabled=!mine?.agent;
 const everyone=w.players.filter(p=>p.connected);$('start').disabled=!everyone.length||everyone.some(p=>!p.agent||!p.ready);
 $('lobbyStatus').textContent=everyone.length+'/5 agentes conectados · '+(everyone.every(p=>p.ready)?'Tudo pronto para entrar!':'Aguardando escolha e confirmação');
 const slots=$('slots');slots.replaceChildren();for(let i=0;i<5;i++){const p=everyone[i];const el=document.createElement('div');el.className='slot';if(p){if(p.agent){const img=new Image();img.src='/assets/'+p.agent+'.jpg';el.append(img);}const b=document.createElement('b');b.textContent=p.name+(p.token===me?' (você)':'');const s=document.createElement('small');s.className=p.ready?'ready':'';s.textContent=(p.agent?NAME[p.agent]:'Escolhendo...')+' · '+(p.ready?'PRONTO':'NÃO PRONTO');el.append(b,s);}else el.textContent='AGUARDANDO AGENTE';slots.append(el);}
 const selector=$('heroSelect');selector.replaceChildren();for(const a of AGENTS){const other=everyone.some(p=>p.agent===a.id&&p.token!==me),btn=document.createElement('button');btn.className='hero-btn'+(mine?.agent===a.id?' on':'');btn.disabled=other;const img=new Image();img.src='/assets/'+a.id+'.jpg';const title=document.createElement('strong');title.textContent=NAME[a.id];const role=document.createElement('small');role.textContent=other?'OCUPADO':{solar:'SNIPER',ritual:'OCULTISTA',alvo:'MACHADO DE SANGUE',feras:'ESCOPETA',lunar:'SUPORTE'}[a.id];btn.append(img,title,role);btn.addEventListener('click',()=>{userGesture();sending({type:'choose',agent:a.id});});selector.append(btn);}
}
function updateCardCountdown(){
 if(!world||world.phase!=='cards')return;
 const timer=$('cardTimer');if(!timer)return;
 const seconds=Math.max(0,Math.ceil((world.cardDeadline-Date.now())/1000));
 const message=seconds>0?'⏱ '+seconds+'s para escolher':'⏱ Tempo encerrado · aplicando carta automática...';
 if(timer.textContent!==message)timer.textContent=message;
}
setInterval(updateCardCountdown,200);
function renderCards(w){updateCardCountdown();const c=JSON.stringify(w.choices)+'|'+w.chosen;if(choicesOld===c)return;choicesOld=c;const list=$('cardOptions');list.replaceChildren();$('cardStatus').textContent=w.chosen?'Você escolheu. Esperando os outros agentes...':'Escolha uma das três cartas para continuar.';
 for(const [i,card] of (w.choices||[]).entries()){const btn=document.createElement('button');btn.className='card';const em=document.createElement('span');em.className='emoji';em.textContent=card[1];const b=document.createElement('b');b.textContent=card[2];const d=document.createElement('p');d.textContent=card[3];const r=document.createElement('span');r.className='rarity '+card[4];r.textContent=({common:'COMUM',rare:'RARA',epic:'ÉPICA',legendary:'LENDÁRIA'})[card[4]]||'COMUM';btn.append(em,b,d,r);btn.onclick=()=>{userGesture();sending({type:'card',index:i});btn.disabled=true;};list.append(btn);}
}
function renderHud(w){const p=w.players.find(p=>p.token===me);if(!p)return;const health=Math.max(0,100*p.hp/(p.maxHp||1));const portraitSrc='/assets/'+p.agent+'.jpg';if(!$('myPortrait').src.endsWith(portraitSrc))$('myPortrait').src=portraitSrc;$('myName').textContent=NAME[p.agent];$('myLife').textContent=Math.ceil(p.hp)+' / '+p.maxHp+' PV'+(p.shield?' +'+p.shield+' escudo':'');$('myHealth').style.width=health+'%';$('waveLabel').textContent='ONDA '+String(w.wave).padStart(2,'0');$('enemyLabel').textContent=w.enemies.length+' CRIATURAS';$('ultFill').style.width=w.ult+'%';$('ultText').textContent=w.ult+'%';$('ult').disabled=w.ult<100;
 const party=$('party'),mates=w.players.filter(a=>a.token!==me&&a.agent),pSig=mates.map(a=>[a.token,a.agent,a.name,a.connected,Math.round(100*a.hp/(a.maxHp||1))].join(':')).join('|');if(pSig!==partyLast){partyLast=pSig;party.replaceChildren();for(const a of mates){const el=document.createElement('div');el.className='p';const name=document.createElement('b');name.textContent=HERO[a.agent]+' '+a.name+(a.connected?'':' (OFF)');const bar=document.createElement('div');bar.className='bar';const fill=document.createElement('div');fill.className='fill';fill.style.width=Math.max(0,100*a.hp/(a.maxHp||1))+'%';bar.append(fill);el.append(name,bar);party.append(el);}}
 const boss=w.enemies.find(e=>['sol','diretora','tv'].includes(e.kind));$('bossBar').hidden=!boss;if(boss){$('bossTitle').textContent=({sol:'☀ SOL SORRIDENTE',diretora:'📺 A DIRETORA',tv:'📺 O OBSERVADOR — TV'})[boss.kind]+(boss.phase2?' · ATO II':' · ATO I');$('bossHealth').style.width=Math.max(0,100*boss.hp/boss.maxHp)+'%';}
 $('skill').querySelector('small').textContent=p.skillCd>0?Math.ceil(p.skillCd)+'s':'RITUAL';$('dash').querySelector('small').textContent=p.dashCd>0?Math.ceil(p.dashCd)+'s':'ESQUIVA';}
function addChat(name,text){const el=document.createElement('div');el.textContent=name+': '+text;$('chatLines').append(el);while($('chatLines').children.length>5)$('chatLines').firstElementChild.remove();}
function scale(){
 resizeW=canvas.clientWidth;resizeH=canvas.clientHeight;
 const maxDpr=ecoGraphics?.85:lowGraphics?1.15:1.5;
 const pxBudget=ecoGraphics?210000:lowGraphics?370000:1100000;
 dpr=Math.min(devicePixelRatio||1,maxDpr,Math.sqrt(pxBudget/Math.max(1,resizeW*resizeH)));
 canvas.width=Math.max(1,Math.round(resizeW*dpr));canvas.height=Math.max(1,Math.round(resizeH*dpr));
 canvas.style.imageRendering=lowGraphics?'pixelated':'auto';
}
window.addEventListener('resize',scale);scale();
function posFor(o,dt){
 const key=o.token??o.id;
 if(framePositions.has(key))return framePositions.get(key);
 let p=visualPos.get(key);
 if(!p){p={x:o.x,y:o.y,corrX:0,corrY:0};visualPos.set(key,p);}
 if(o.token===me&&world?.phase==='fight'&&o.hp>0){
  // Predição visual: o próprio personagem responde a cada frame, sem aguardar WebSocket.
  const m=getMove(),speed=limit(Number(o.speed)||220,0,700);
  p.x=limit(p.x+m.x*speed*dt,BOUND.l+22,BOUND.r-22);
  p.y=limit(p.y+m.y*speed*dt,BOUND.t+22,BOUND.b-22);
  // Pequena correção suave ao receber a posição definitiva do servidor.
  const alpha=Math.min(1,dt*9);
  const changeX=(p.corrX||0)*alpha,changeY=(p.corrY||0)*alpha;
  p.x=limit(p.x+changeX,BOUND.l+22,BOUND.r-22);
  p.y=limit(p.y+changeY,BOUND.t+22,BOUND.b-22);
  p.corrX=(p.corrX||0)-changeX;p.corrY=(p.corrY||0)-changeY;
 }else{
  const velocity=netVelocity.get(key),age=limit((performance.now()-stateAt)/1000,0,.12);
  const projectedX=limit(o.x+(velocity?.vx||0)*age,BOUND.l,BOUND.r);
  const projectedY=limit(o.y+(velocity?.vy||0)*age,BOUND.t,BOUND.b);
  const distance=Math.hypot(projectedX-p.x,projectedY-p.y);
  if(distance>135){p.x=projectedX;p.y=projectedY;}
  else {const alpha=1-Math.exp(-dt*17);p.x+=(projectedX-p.x)*alpha;p.y+=(projectedY-p.y)*alpha;}
 }
 framePositions.set(key,p);return p;
}
// Chefes pré-renderizados no modo leve: preserva a arte e evita centenas de traços por frame.
const bossSprites=new Map();
function bossSprite(e){
 const key=e.kind+(e.phase2?'2':'1');if(bossSprites.has(key))return bossSprites.get(key);
 const c=document.createElement('canvas');c.width=240;c.height=300;
 const g=c.getContext('2d');g.translate(120,170);
 renderBoss(g,{kind:e.kind,x:0,y:0,phase2:!!e.phase2},0);
 bossSprites.set(key,c);return c;
}
function render(ts){const minInterval=world?.phase==='fight'?(ecoGraphics?31.5:15.5):150;if(render.prev&&ts-render.prev<minInterval){requestAnimationFrame(render);return;}const dt=Math.min(.05,(ts-(render.prev||ts))/1000);render.prev=ts;framePositions.clear();framesSeen++;updateStats(ts);const secs=ts/1000;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#08060e';ctx.fillRect(0,0,resizeW,resizeH);
 if(!world||world.phase==='lobby'){const map=mapForQuality();if(map.naturalWidth){ctx.globalAlpha=.48;const z=Math.max(resizeW/W,resizeH/H);ctx.imageSmoothingEnabled=!lowGraphics;ctx.drawImage(map,(resizeW-W*z)/2,(resizeH-H*z)/2,W*z,H*z);ctx.globalAlpha=1;}requestAnimationFrame(render);return;}
 const focus=world.players.find(p=>p.token===me)||world.players[0],fp=focus?posFor(focus,dt):{x:750,y:550};const zoom=Math.max(.31,Math.min(resizeW/990,resizeH/570));const hx=resizeW/(2*zoom),hy=resizeH/(2*zoom);const cx=hx*2>=W?W/2:Math.max(hx,Math.min(W-hx,fp.x));const cy=hy*2>=H?H/2:Math.max(hy,Math.min(H-hy,fp.y));
 ctx.save();if(shake>0){shake*=.91;if(shake<.5)shake=0;ctx.translate((Math.random()-.5)*shake,(Math.random()-.5)*shake);}ctx.translate(resizeW/2,resizeH/2);ctx.scale(zoom,zoom);ctx.translate(-cx,-cy);
 const map=mapForQuality();ctx.imageSmoothingEnabled=!lowGraphics;if(map.naturalWidth){ctx.drawImage(map,0,0,W,H);}else{ctx.fillStyle='#241923';ctx.fillRect(0,0,W,H);}
 ctx.imageSmoothingEnabled=false;
 const seen=(x,y,r=75)=>x+r>=cx-hx&&x-r<=cx+hx&&y+r>=cy-hy&&y-r<=cy+hy;
 for(const z of world.warnings){if(z.type==='circle'&&!seen(z.x,z.y,z.r))continue;ctx.save();const blink=.3+.28*Math.sin(secs*24)**2;ctx.strokeStyle=z.color||'#ff9e92';ctx.fillStyle=z.type==='circle'?'#a8343645':'#fb8a6760';ctx.globalAlpha=.5+blink;ctx.lineWidth=5;if(z.type==='circle'){ctx.beginPath();ctx.arc(z.x,z.y,z.r,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.beginPath();ctx.arc(z.x,z.y,Math.max(0,z.r*(1-z.life/z.duration)),0,Math.PI*2);ctx.stroke();}else{ctx.beginPath();ctx.moveTo(z.x,z.y);ctx.lineTo(z.x+Math.cos(z.a)*z.len,z.y+Math.sin(z.a)*z.len);ctx.lineWidth=z.r*2;ctx.stroke();}ctx.restore();}
 // Kits de vida verdes no chao: desenhar antes dos personagens para nao cobrir os sprites.
 for(const item of world.pickups||[]){
  if(!seen(item.x,item.y,35))continue;
  const wobble=Math.sin(secs*4+item.id)*2;
  ctx.save();ctx.translate(item.x,item.y+wobble);
  // Simbolo simples e rapido, visivel mesmo com qualidade ECO/pixelizada.
  ctx.fillStyle='#082a21';ctx.fillRect(-13,-13,26,26);
  ctx.fillStyle=item.heal>=40?'#89ffd4':'#45ef9d';ctx.fillRect(-10,-10,20,20);
  ctx.fillStyle='#effff4';ctx.fillRect(-3,-8,6,16);ctx.fillRect(-8,-3,16,6);
  if(item.life<5){ctx.globalAlpha=.35+.6*(.5+.5*Math.sin(secs*13));ctx.strokeStyle='#b8ffdb';ctx.strokeRect(-13,-13,26,26);}
  ctx.restore();
 }
 const all=[...world.players.filter(p=>p.agent).map(p=>({kind:'player',data:p})),...world.enemies.map(e=>({kind:'enemy',data:e}))].filter(item=>seen(item.data.x,item.data.y,130)).sort((a,b)=>a.data.y-b.data.y);
 for(const obj of all){const o=obj.data,v=posFor(o,dt);ctx.save();ctx.translate(v.x,v.y);ctx.fillStyle='#05040a99';ctx.beginPath();ctx.ellipse(0,23,22,8,0,0,Math.PI*2);ctx.fill();ctx.restore();
  if(obj.kind==='player'){const i=AGENTS.findIndex(a=>a.id===o.agent);if(i<0)continue;let frame=o.fx>0?3:o.move?(Math.floor(secs*9+i)%2?1:2):0;ctx.globalAlpha=o.hp<=0?.36:!o.connected?.56:1;ctx.drawImage(ART.heroes[i][frame],v.x-27,v.y-40+(o.move?Math.sin(secs*13)*2:0),54,65);ctx.globalAlpha=1;
   ctx.save();ctx.translate(v.x,v.y+3);ctx.rotate(o.dir||0);if(o.agent==='alvo'){ctx.fillStyle='#642037';ctx.fillRect(10,-3,44,7);ctx.fillStyle='#f55c74';ctx.fillRect(46,-18,18,36);ctx.fillStyle='#dba7b1';ctx.fillRect(60,-10,7,21);ctx.fillStyle='#ffb3b8';ctx.fillRect(50,-15,11,7);}else if(o.agent==='solar'){ctx.fillStyle='#2b2427';ctx.fillRect(4,-4,59,9);ctx.fillStyle='#eac078';ctx.fillRect(37,-6,24,3);}else if(o.agent==='feras'){ctx.fillStyle='#271d22';ctx.fillRect(5,-6,37,14);ctx.fillStyle='#e7b0a1';ctx.fillRect(17,-7,10,3);}else{ctx.strokeStyle=AGENTS[i].accent;ctx.lineWidth=4;ctx.beginPath();ctx.arc(31,0,14,0,Math.PI*2);ctx.stroke();}ctx.restore();
   if(o.token===me){ctx.strokeStyle='#f3dca8';ctx.lineWidth=2;ctx.beginPath();ctx.arc(v.x,v.y+20,27,0,Math.PI*2);ctx.stroke();}
   const label=(o.token===me?'VOCÊ • ':'')+o.name;ctx.font='bold 12px system-ui';ctx.textAlign='center';ctx.lineWidth=3;ctx.strokeStyle='#0e080c';ctx.strokeText(label,v.x,v.y-48);ctx.fillStyle=o.connected?'#f8e9db':'#b5aab0';ctx.fillText(label,v.x,v.y-48);
   ctx.fillStyle='#27141c';ctx.fillRect(v.x-23,v.y-45,46,5);ctx.fillStyle=AGENTS[i].accent;ctx.fillRect(v.x-22,v.y-44,44*Math.max(0,o.hp/(o.maxHp||1)),3);
  }else{const e=o;ctx.save();ctx.translate(v.x-e.x,v.y-e.y);if(['sol','diretora','tv'].includes(e.kind)){if(lowGraphics)ctx.drawImage(bossSprite(e),e.x-120,e.y-170);else renderBoss(ctx,e,secs);}else{const frames=ART.monsters[e.kind]||ART.monsters.sangue,fr=Math.floor(secs*(e.kind==='rastejante'?11:7))%3,s=e.kind==='bruto'?70:e.kind==='cacador'?64:53;ctx.drawImage(frames[fr],e.x-s/2,e.y-s/2,s,s);}ctx.restore();
   ctx.fillStyle='#160e15bb';ctx.fillRect(v.x-e.r,v.y-e.r-21,e.r*2,6);ctx.fillStyle=['sol','diretora','tv'].includes(e.kind)?'#ffc07d':'#e65771';ctx.fillRect(v.x-e.r+1,v.y-e.r-20,Math.max(0,(e.r*2-2)*e.hp/e.maxHp),4);
  }
 }
 for(const s of world.shots){if(!seen(s.x,s.y,25))continue;ctx.save();ctx.fillStyle=s.color;if(!lowGraphics){ctx.shadowColor=s.color;ctx.shadowBlur=8;}ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fill();ctx.restore();}
 for(const fx of world.effects||[]){if(!seen(fx.x,fx.y,400))continue;if(fx.t==='ultimate'){ctx.fillStyle='#ffe5b33b';ctx.beginPath();ctx.arc(fx.x,fx.y,350,0,Math.PI*2);ctx.fill();}else if(['blood','ritual','heal','warp','rage'].includes(fx.t)){ctx.strokeStyle=fx.t==='blood'?'#ff4268':fx.t==='heal'?'#ffc3eb':'#c08dff';ctx.lineWidth=5;ctx.beginPath();ctx.arc(fx.x,fx.y,70+Math.sin(secs*10)*10,0,Math.PI*2);ctx.stroke();}else if(fx.t==='axe'){ctx.strokeStyle='#fb526d';ctx.lineWidth=13;ctx.beginPath();ctx.arc(fx.x,fx.y,85,fx.a-.95,fx.a+.95);ctx.stroke();}else if(fx.t==='laser'){ctx.strokeStyle='#ffdf9b';ctx.lineWidth=11;ctx.beginPath();ctx.moveTo(fx.x,fx.y);ctx.lineTo(fx.x2,fx.y2);ctx.stroke();}}
 ctx.restore();if(!lowGraphics){ctx.fillStyle='#00000013';for(let y=0;y<resizeH;y+=5)ctx.fillRect(0,y,resizeW,1);}requestAnimationFrame(render);
}requestAnimationFrame(render);
const getMove=()=>{const x=(keys.has('d')||keys.has('arrowright')?1:0)-(keys.has('a')||keys.has('arrowleft')?1:0)+touch.x,y=(keys.has('s')||keys.has('arrowdown')?1:0)-(keys.has('w')||keys.has('arrowup')?1:0)+touch.y;const len=Math.hypot(x,y)||1;return{x:x/Math.max(1,len),y:y/Math.max(1,len)};};
setInterval(()=>{if(world&&['cards','between'].includes(world.phase))sending({type:'tick'});},1500);
let lastInputSent=0;
function sendInput(){if(!world||world.phase!=='fight'||ws?.readyState!==WebSocket.OPEN)return;
 const m=getMove();sending({type:'input',x:m.x,y:m.y,fire:touch.fire||keys.has(' ')||keys.has('j'),skill:pending.skill,dash:pending.dash,ult:pending.ult});
 pending.skill=false;pending.dash=false;pending.ult=false;lastInputSent=performance.now();
}
function fastInput(){if(performance.now()-lastInputSent>=35)sendInput();}
setInterval(sendInput,100);
window.addEventListener('keydown',e=>{const k=e.key.toLowerCase();if([' ','arrowup','arrowdown','arrowleft','arrowright'].includes(k)&&document.activeElement?.tagName!=='INPUT')e.preventDefault();if(document.activeElement?.tagName==='INPUT')return;keys.add(k);if(k==='e'||k==='q')pending.skill=true;if(k==='shift')pending.dash=true;if(k==='f')pending.ult=true;if(!e.repeat)fastInput();});
window.addEventListener('keyup',e=>{keys.delete(e.key.toLowerCase());fastInput();});window.addEventListener('blur',()=>{keys.clear();touch.fire=false;touch.x=touch.y=0;});
canvas.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&world?.phase==='fight'){touch.fire=true;fastInput();}});window.addEventListener('pointerup',e=>{if(e.pointerType==='mouse'){touch.fire=false;fastInput();}});
const stick=$('joystick'),knob=$('knob');let pointer=null;function onStick(e){const r=stick.getBoundingClientRect(),x=e.clientX-r.left-r.width/2,y=e.clientY-r.top-r.height/2,len=Math.hypot(x,y)||1,max=r.width*.33;touch.x=x/Math.max(len,max);touch.y=y/Math.max(len,max);knob.style.transform=`translate(${touch.x*max}px,${touch.y*max}px)`;}
stick.addEventListener('pointerdown',e=>{pointer=e.pointerId;stick.setPointerCapture(e.pointerId);onStick(e);fastInput();});stick.addEventListener('pointermove',e=>{if(pointer===e.pointerId){onStick(e);fastInput();}});function resetStick(e){if(pointer===e.pointerId){pointer=null;touch.x=touch.y=0;knob.style.transform='translate(0,0)';fastInput();}}stick.addEventListener('pointerup',resetStick);stick.addEventListener('pointercancel',resetStick);
for(const id of ['fire','skill','dash','ult']){const el=$(id);el.addEventListener('pointerdown',e=>{e.preventDefault();el.classList.add('pressed');el.setPointerCapture(e.pointerId);if(id==='fire')touch.fire=true;else pending[id]=true;fastInput();userGesture();});const stop=()=>{el.classList.remove('pressed');if(id==='fire'){touch.fire=false;fastInput();}};el.addEventListener('pointerup',stop);el.addEventListener('pointercancel',stop);}
$('create').onclick=()=>{userGesture();connect(true)};$('join').onclick=()=>{userGesture();connect(false)};$('ready').onclick=()=>sending({type:'ready'});$('start').onclick=()=>{userGesture();sending({type:'start'});};$('again').onclick=()=>sending({type:'restart'});
$('copy').onclick=async()=>{const link=location.origin+'/?sala='+roomCode;try{await navigator.clipboard.writeText(link);$('copy').textContent='✓ LINK COPIADO';}catch{window.prompt('Copie o link da sala:',link);}};
const leave=()=>{offline=true;try{ws?.close();}catch{}history.replaceState(null,'',location.pathname);location.reload();};$('exitLobby').onclick=leave;$('back').onclick=leave;
$('chatForm').onsubmit=e=>{e.preventDefault();const t=$('chatInput').value.trim();if(t)sending({type:'chat',text:t});$('chatInput').value='';};$('soundBtn').onclick=()=>{musicOn=!musicOn;audio.muted=!musicOn;$('soundBtn').textContent=musicOn?'♫':'×';if(musicOn)userGesture();};const qualityBtn=$('qualityBtn');function qualityLabel(){
 qualityBtn.textContent=ecoGraphics?'ECO':lowGraphics?'⚡':'HD';
 qualityBtn.title=ecoGraphics?'Modo econômico (30 FPS). Toque para HD.':lowGraphics?'Modo leve (até 60 FPS). Toque para econômico.':'HD (até 60 FPS). Toque para leve.';
}
qualityBtn.onclick=()=>{
 if(ecoGraphics){ecoGraphics=false;lowGraphics=false;}
 else if(lowGraphics){ecoGraphics=true;}
 else {lowGraphics=true;}
 lowFpsSeconds=0;lastQualityAdjust=performance.now();qualityLabel();scale();
};qualityLabel();
const code=new URLSearchParams(location.search).get('sala');if(code){$('roomInput').value=code.toUpperCase();$('entryStatus').textContent='Sala do convite detectada. Escreva seu nome e toque em ENTRAR COM CÓDIGO.';}

// Reiniciar contadores ao voltar do segundo plano, evitando FPS falso.
document.addEventListener('visibilitychange',()=>{fpsStart=performance.now();framesSeen=0;lowFpsSeconds=0;render.prev=0;});
