# PROJETO SORRISO ONLINE V12.7 — RELÍQUIA DE ENERGIA + PESADELO

Atualização da V12.6, preservando cinco agentes, curas no chão, cartas, trilhas, o modo de história V11 e as ondas infinitas.

## Melhorias

- **Cartas:** espera de 3 segundos depois da onda e, só então, 10 segundos para escolher. Jogadores que não escolherem recebem carta automática. Depois, 1 segundo até a próxima onda.
- **HUD horizontal:** barra de chefe fixada no topo, painel de equipe e botões reduzidos, chat escondido em telas deitadas muito baixas.
- **Tiros suaves:** cada tiro recebe um identificador e velocidade do servidor; o navegador anima entre pacotes sem alterar o cálculo de colisão.
- **Onda 20:** novo chefe **Relíquia de Energia**, usando a imagem fornecida pelo criador, introdução cinematográfica de 4,8 s, arena dimensional com estrelas e sigilos, três atos e oito padrões (raios, feixes, orbes, prisão, magnetismo, ecos, chuva elétrica, colapso com zona segura), teleportes e escudos de núcleos. O ciclo continua: 5 Sol, 10 Diretora, 15 TV, 20 Relíquia, e repete em 25–40 etc.
- **Modo Pesadelo:** selecionável ao criar a sala; +50% de vida inicial dos inimigos, +30% de dano, mais inimigos e crescimento adaptativo à progressão; limite ao acúmulo de bônus de dano das cartas. Normal preservado.
- **Curas verdes preservadas**, com drop de inimigos e chefes como na V12.6.

## Instalação pelo GitHub Codespaces

Envie **Projeto_Sorriso_Online_V12_7_Atualizacao.zip** para a raiz do repositório com **Add file → Upload files → Commit changes**. Depois execute no terminal, um por vez:

```bash
cd /workspaces/projeto-sorriso-online
git pull --ff-only
ls -lh Projeto_Sorriso_Online_V12_7_Atualizacao.zip
unzip -oq Projeto_Sorriso_Online_V12_7_Atualizacao.zip
grep -q 'V12.7 RELÍQUIA DE ENERGIA' Projeto_Sorriso_Online_V12/public/index.html && echo 'V12.7 confirmada'
cd Projeto_Sorriso_Online_V12
npm run check
npm test
npm run deploy
```

A **pasta interna continua `Projeto_Sorriso_Online_V12`**; isso é normal e mantém a hospedagem no mesmo lugar. No menu aparecerá **V12.7 RELÍQUIA DE ENERGIA**. O endereço online continua `https://projeto-sorriso-online.projeto-sorriso-davis546.workers.dev`.

Crie **sala nova** para escolher Normal/Pesadelo. Recarregue o Chrome com `Ctrl + Shift + R`. Ainda é necessário validar o desempenho real com cinco jogadores e testar a luta da onda 20 depois de publicar. O serviço continua sujeito aos limites gratuitos da Cloudflare.
